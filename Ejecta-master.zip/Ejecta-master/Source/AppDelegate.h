#import <UIKit/UIKit.h>
#import "EJAppViewController.h"

@interface AppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) UIWindow *window;
@end

