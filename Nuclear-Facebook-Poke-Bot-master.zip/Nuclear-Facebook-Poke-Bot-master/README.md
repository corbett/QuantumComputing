Nuclear-Facebook-Poke-Bot
=========================

Facebook Poke Bot is easy to use and automatically "pokes" AND "pokes back" everybody.  Written in Python and PHP.
