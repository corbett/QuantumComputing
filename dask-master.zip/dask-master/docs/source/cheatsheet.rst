Dask Cheat Sheet
================

The 300KB pdf :download:`dask cheat sheet <daskcheatsheet.pdf>`
is a single page summary about using dask.
It is commonly distributed at conferences and trade shows.
