Kubernetes Native
=================

See external documentation on Dask-Kubernetes_ for more information.

.. _Dask-Kubernetes: https://kubernetes.dask.org
