This page has moved.  Please see :doc:`setup` instead.
