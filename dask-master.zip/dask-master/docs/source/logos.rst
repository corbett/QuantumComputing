Images and Logos
================

.. image:: images/dask_icon.svg
   :alt: Dask logo

.. image:: images/dask_icon_no_pad.svg
   :alt: Dask logo without padding

.. image:: images/dask_horizontal.svg
   :alt: Dask logo

.. image:: images/dask_horizontal_no_pad.svg
   :alt: Dask logo without padding

.. image:: images/dask_horizontal_white.svg
   :alt: Dask logo

.. image:: images/dask_horizontal_white_no_pad.svg
   :alt: Dask logo

.. image:: images/dask_stacked.svg
   :alt: Dask logo

.. image:: images/dask_stacked_white.svg
   :alt: Dask logo

.. image:: images/HHMI_Janelia_Color.png
   :alt: HHMI Janelia logo
