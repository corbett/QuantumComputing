#   God's Eye

This is a command line tool that substitute the ` sudo ` command so that we donot have to enter the password every time (coz we are lazy !!).


##  How to Install

1. Clone the repository from GitHub :  

        git clone "https://github.com/BugHoppers/gods_eye.git"  


2. Run the script :  

        ./OpenGodsEye.sh  


##  Configure God's Eye

1. Create a file name ` config.ge ` and write your sudo password  

2. Add the directory to the PATH



##  How to Run

        god < command >

