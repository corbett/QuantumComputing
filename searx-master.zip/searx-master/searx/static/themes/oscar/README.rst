install dependencies
~~~~~~~~~~~~~~~~~~~~

run this command in the directory ``searx/static/themes/oscar``

``npm install``

compile sources
~~~~~~~~~~~~~~~

run this command in the directory ``searx/static/themes/oscar``

``grunt``

or in the root directory:

``make grunt``
