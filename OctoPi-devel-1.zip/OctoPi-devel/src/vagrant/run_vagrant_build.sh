#!/usr/bin/env bash
sudo vagrant ssh -- -t "sudo /CustomPiOS/nightly_build_scripts/custompios_nightly_build $@"

