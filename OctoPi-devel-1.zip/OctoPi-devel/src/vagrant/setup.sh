#!/usr/bin/env bash
sudo apt-get update
sudo apt-get install -y gawk util-linux realpath git qemu-user-static p7zip-full unzip zip

