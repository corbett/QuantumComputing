OctoPrint 1.3.6 and newer no longer rely on a git checkout for updates,
so OctoPi no longer goes that route either.

Feel free to manually create a git clone though if you need it (e.g. for
branch based updates or on board development):

    ~/scripts/add-octoprint-checkout
