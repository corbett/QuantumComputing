# smtp-server

![Nodemailer](https://raw.githubusercontent.com/nodemailer/nodemailer/master/assets/nm_logo_200x136.png)

Node.JS module for creating SMTP and LMTP server instances on the fly.

See [smtp-server homepage](https://nodemailer.com/extras/smtp-server/) for documentation and terms.
