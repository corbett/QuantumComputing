## Installation

To install, please run:

    wget https://github.com/mistio/REPO/releases/download/TAG/docker-compose.yml
    docker-compose up -d

Also see the following README sections:

- https://github.com/mistio/REPO/tree/TAG#running-mistio
- https://github.com/mistio/REPO/tree/TAG#managing-mistio
