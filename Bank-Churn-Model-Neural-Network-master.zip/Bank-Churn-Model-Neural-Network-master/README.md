# Bank-Churn-Model-Neural-Network
Artificial Neural Network to predict which customers are likely to leave the bank

A bank dataset contains records of customers with the following columns:

'CustomerId'
'Surname'
'CreditScore'
'Geography'
'Gender'
'Age'
'Tenure'
'Balance'
'NumOfProducts'
'HasCrCard'
'IsActiveMember'
'EstimatedSalary'
Bank-Churn-Model-Neural-Network/unknown 2
'Exited'

Exited is the target variable which is 1 or 0 depending upon if the customer is leaving or not 
    
