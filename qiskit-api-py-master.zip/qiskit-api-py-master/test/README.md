# Python API Client IBM Quantum Experience TEST

To run the tests (unittest), you need configure the **API_TOKEN** of the Quantum Experience Platform in *config.py* file:

```
API_TOKEN = 'YOUR_API_TOKEN'
```

Then, you have to run under the main directory:

```
python -m unittest discover -v
```
