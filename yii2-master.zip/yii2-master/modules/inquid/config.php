<?php
/**
 * Created by PhpStorm.
 * User: kholmatov
 * Date: 30/08/2018
 * Time: 03:29
 */

return [
    'components' => [
        // список конфигураций компонентов
    ],
    'params' => [
        // список параметров
    ],
];