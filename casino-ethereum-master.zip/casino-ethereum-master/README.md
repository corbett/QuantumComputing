# casino-ethereum
This is a simple casino build with solidity, truffle and react
