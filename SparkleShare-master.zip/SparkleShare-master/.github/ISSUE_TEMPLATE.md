You can find session logs by date and version information in:
~/.config/org.sparkleshare.SparkleShare/logs/ on Linux and macOS
C:\Users\YOUR_USERNAME\AppData\Roaming\org.sparkleshare.SparkleShare\logs\ on Windows

To help us help you, please include the logs from around the time the issue occurred, as well as the SparkleShare version and info about your OS (displayed at the top of the log files). Then, tell us roughly in these steps what went wrong:


### What happened:
…

### What I expected to happen:
…

### This happens when:
1. …
2. …
3. …


Thanks for reporting your issue or feature request, it helps lots!
