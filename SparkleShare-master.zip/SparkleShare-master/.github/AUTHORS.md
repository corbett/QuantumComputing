Maintainer:

	Hylke Bons <hi@planetpeanut.uk>

Code:

	Alejandro Serrano <trupill@gmail.com>
	Alexandre Saiz Verdaguer <a@alexandresaiz.com>
	Alex Hudson <home@alexhudson.com>
	Benjamin Podszun <benjamin.podszun@gmail.com>
	Bertrand Lorentz <bertrand.lorentz@gmail.com>
	Chris Magee <chris.magee@gametheworld.com>
	Gabriel Burt <gabriel.burt@gmail.com>
	Garrett LeSage <garrett@novell.com>
	Hylke Bons <hi@planetpeanut.uk>
	Jonathan Haines <jonno.haines@gmail.com>
	Kristi Tsukida <kristi.tsukida@gmail.com>
	Konstantinos Vaggelakos <kozze89@gmail.com>
	Lars Falk-Petersen <dev@falk-petersen.no>
	Luis Cordova <cordoval@gmail.com>
	Łukasz Jernaś <deejay1@srem.org>
	Markus Stoll <post@mstoll.de>
	Michael Monreal <michael.monreal@gmail.com>
	Nick Richards <nick@nickr.org>
	Oleg Khlystov <pktfag@gmail.com>
	Paul Cutler <pcutler@gnome.org>
	Philipp Gildein <rmbl@openspeak-project.org>
	Ruben Vermeersch <rubenv@gnome.org>
	Sandy Armstrong <sanfordarmstrong@gmail.com>
	Shish <shish@shishnet.org>
	Simon Pither <simon@pither.com>
	Steven Harms <sharms@ubuntu.com>
	Sven Mueller <thelightmaker@gmail.com>
	Travis Glenn Hansen <travisghansen@yahoo.com>
	Vincent Untz <vuntz@gnome.org>
	Will Thompson <will@willthompson.co.uk>
		
Design:

	Andreas Nilsson <andreasn@gnome.org>
	Jakub Steiner <jimmac@redhat.com>
	Hylke Bons <hi@planetpeanut.uk>
	Lapo Calamandrei <calamandrei@gmail.com>
	Sam Hewitt <hewittsamuel@gmail.com>

Thanks very much!

