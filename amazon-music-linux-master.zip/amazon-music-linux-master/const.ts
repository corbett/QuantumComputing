/**
 * @author Flo Dörr
 * @email flo@dörr.site
 * @create date 2018-08-26 02:37:53
 * @modify date 2018-08-26 03:26:37
 * @desc this projects constants
 */
export const APP_NAME: string = "Amazon Music";
