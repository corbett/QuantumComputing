<?php


namespace Nuclear\Hierarchy\Exception;


use RuntimeException;

class InvalidParentNodeTypeException extends RuntimeException {

}