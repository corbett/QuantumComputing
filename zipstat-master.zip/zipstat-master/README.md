# zipstat
Year 2000 style full featured website statistics service, witch can be used to register almost anything posible about a websites visitors.

The project was started in 1998, then in Perl, but since ported to PHP and developed until about 2008, where the project effectively went into maintenance. Since then only security bugs and support of new browsers have been addressed.

Getting a modern system will require a rewrite today, so this project will stay in maintenance mode. It still works fine and everybody are welcome to fork it or contribute.
