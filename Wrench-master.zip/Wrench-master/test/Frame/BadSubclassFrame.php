<?php

namespace Wrench\Frame;

class BadSubclassFrame extends HybiFrame
{
    protected $payload = 'asdmlasdkm';
    protected $buffer = false;
}
