<?php

namespace Wrench\Frame;

class HybiFrameTest extends FrameBaseTest
{
}
