<?php

namespace Wrench\Socket;

class ServerSocketTest extends UriSocketTest
{
}
