<?php

namespace Wrench\Payload;

class HybiPayloadTest extends PayloadBaseTest
{
}
