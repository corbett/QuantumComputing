<?php

namespace Wrench\Protocol;

class Rfc6455ProtocolTest extends ProtocolBaseTest
{
}
