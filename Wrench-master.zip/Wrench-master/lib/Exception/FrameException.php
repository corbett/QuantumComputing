<?php
namespace Wrench\Exception;

use Wrench\Exception\Exception as WrenchException;

class FrameException extends WrenchException
{
}
