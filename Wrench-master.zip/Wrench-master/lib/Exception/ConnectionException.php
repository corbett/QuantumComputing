<?php

namespace Wrench\Exception;

class ConnectionException extends Exception
{
}
