----------------
Wrench\\Resource
----------------

.. php:namespace: Wrench

.. php:class:: Resource

    Resource interface

    .. php:method:: getResourceId()

    .. php:method:: getResource()
