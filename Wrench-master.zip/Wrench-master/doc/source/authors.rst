-------
Authors
-------

The original maintainer and author was `@nicokaiser
<https://github.com/nicokaiser>`_. Plentiful improvements were contributed by
`@lemmingzshadow <https://github.com/lemmingzshadow>`_ and `@mazhack
<https://github.com/mazhack>`_. Parts of the Socket class were written by
Moritz Wutz. The server is licensed under the WTFPL, a free software compatible
license.

