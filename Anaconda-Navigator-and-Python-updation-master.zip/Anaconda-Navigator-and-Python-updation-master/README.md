# Anaconda-Navigator-and-Python-updation
1.  Most of the time the process of installation leads to errors.

2.  Here I am providing steps to upgrade your python in anaconda navigation without loss of any stacks. 

3.  First launch your anaconda prompt.

4.  Its better to update your anaconda naviagtor to latest version.

5.  Check your anaconda navigator version.

6.  Command    `python --version`

7.  Update Annaconda Navigator using.

8.  Command    `conda update anaconda`

9. Check the updated version of your navigator using command at step 6.

10. Next update your python.

11. Check your anaconda navigator version using command at step 6.

12. Command    `conda update python`

13. This command will update the python at root of Anaconda navigator.

14. Be patient it takes a while during Solving Environment step.

15. Check the updated version of your python using command at step 6.

16. You can see the updated version of your python.

17. Now launch your anaconda navigator.

18. Go to Environment->root and check your dependencies you can see some of the dependency been updated.

19.Next launch your Spyder you can verify the update version of python at left corner top label of Spyder.
