﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Wipefest.Cli;

namespace Wipefest.Api.Infrastructure
{
    public static class WipefestCliExtensions
    {
        public static IActionResult ToActionResult<T>(this WipefestCliResult<T> result) where T : class
        {
            if (result.IsFailure)
                return new ObjectResult(result.Error)
                {
                    StatusCode = result.Status
                };

            return new OkObjectResult(result.Value);
        }

        public static IActionResult ToActionResult<TSource, TDestination>(this WipefestCliResult<TSource> result, Func<TSource, TDestination> map) where TSource : class
        {
            if (result.IsFailure)
                return new ObjectResult(result.Error)
                {
                    StatusCode = result.Status
                };

            return new OkObjectResult(map(result.Value));
        }
    }
}
