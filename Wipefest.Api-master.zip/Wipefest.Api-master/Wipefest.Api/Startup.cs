﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Threading.Tasks;
using Hangfire;
using Hangfire.MemoryStorage;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.PlatformAbstractions;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Conventions;
using MongoDB.Bson.Serialization.Serializers;
using MongoDB.Driver;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using Swashbuckle.AspNetCore.SwaggerUI;
using Wipefest.Api.Factories;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Repositories;
using Wipefest.Api.Services;
using Wipefest.Cli;

namespace Wipefest.Api
{
    public class Startup
    {
        private readonly IHostingEnvironment _env;

        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = configuration;
            _env = env;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddLogging();

            services.AddDistributedRedisCache(options =>
            {
                options.Configuration = Configuration["CacheConnectionString"] ?? "wipefest.api.cache";
                options.InstanceName = "wipefestApiCache";
            });

            services.AddSingleton<WipefestCli>(provider =>
            {
                var warcraftLogsApiKey = Configuration["WarcraftLogsApiKey"];
                var baseUrls = Configuration.GetSection("WipefestCliApiBaseUrls").Get<string[]>();
                var cache = provider.GetService<IDistributedCache>();

                return new CacheableWipefestCliApi(warcraftLogsApiKey, baseUrls, cache);
            });

            var pack = new ConventionPack
            {
                new IgnoreExtraElementsConvention(true)
            };
            ConventionRegistry.Register("Conventions", pack, t => true);
            BsonSerializer.RegisterSerializer(typeof(decimal), new DecimalSerializer(BsonType.Decimal128));
            BsonSerializer.RegisterSerializer(typeof(decimal?), new NullableSerializer<decimal>(new DecimalSerializer(BsonType.Decimal128)));

            services.AddScoped(provider =>
            {
                var connectionString = Configuration["ConnectionString"];

                var client = new MongoClient(connectionString);

                return client.GetDatabase("wipefestapi");
            });

            services.AddSingleton<HttpClient>();
            services.AddTransient<ApiKeyValidator>();
            services.AddTransient<SequenceService>();
            services.AddTransient<WorkspaceRepository>();
            services.AddTransient<FightConfigFactory>();
            services.AddTransient<FightConfigService>();
            services.AddTransient<FightService>();
            services.AddTransient<WorkspaceSeeder>();
            services.AddTransient<StatisticRepository>();
            services.AddTransient<StatisticService>();

            services.AddHangfire(config => config
                .UseFilter(new SuccessfulJobCleanupFilter())
                .UseMemoryStorage(new MemoryStorageOptions
                {
                    JobExpirationCheckInterval = TimeSpan.FromSeconds(10)
                }));

            services.AddMvc()
                .AddJsonOptions(x =>
                {
                    x.SerializerSettings.Converters.Add(new Newtonsoft.Json.Converters.StringEnumConverter());
                    x.SerializerSettings.NullValueHandling = NullValueHandling.Ignore;
                });
            
            services.AddSingleton(Configuration);
            services.AddSwaggerGen(SwaggerGenConfiguration);

            if (_env.IsDevelopment())
            {
                services.AddCors(options =>
                {
                    options.AddPolicy("default", policy => policy
                        .AllowAnyOrigin()
                        .AllowCredentials()
                        .AllowAnyHeader()
                        .AllowAnyMethod());
                });
            }
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseCors("default");
            }

            app.UseHangfireDashboard();
            app.UseHangfireServer();

            app.UseMvc();

            app.UseSwagger();
            app.UseSwaggerUI(SwaggerUIConfiguration);
        }

        private static Action<SwaggerGenOptions> SwaggerGenConfiguration => c =>
        {
            c.SwaggerDoc("v0.1", new Info
            {
                Title = "Wipefest API",
                Version = "v0.1",
                Description = ""
            });
            
            var basePath = PlatformServices.Default.Application.ApplicationBasePath;
            var xmlPath = Path.Combine(basePath, "documentation.xml");
            c.IncludeXmlComments(xmlPath);
            
            c.DescribeAllEnumsAsStrings();
            c.SchemaFilter<EnumTypeSchemaFilter>();
            c.SchemaFilter<NullableTypeSchemaFilter>();
        };

        private static Action<SwaggerUIOptions> SwaggerUIConfiguration => c =>
        {
            c.SwaggerEndpoint("/swagger/v0.1/swagger.json", "Wipefest API");
        };
    }

    public class EnumTypeSchemaFilter : ISchemaFilter
    {
        public void Apply(Schema schema, SchemaFilterContext context)
        {
            var typeInfo = context.SystemType.GetTypeInfo();

            if (typeInfo.IsEnum)
            {
                schema.Extensions.Add(
                    "x-ms-enum",
                    new
                    {
                        name = typeInfo.Name,
                        modelAsString = true
                    });
            }
        }
    }

    public class NullableTypeSchemaFilter : ISchemaFilter
    {
        public void Apply(Schema model, SchemaFilterContext context)
        {
            if (context.SystemType.IsValueType && Nullable.GetUnderlyingType(context.SystemType) == null)
                model.Extensions.Add("x-nullable", false);
        }
    }
}
