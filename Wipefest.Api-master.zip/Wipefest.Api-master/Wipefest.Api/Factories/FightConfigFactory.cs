﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using Newtonsoft.Json;
using Serilog;
using Wipefest.Api.Models;
using Wipefest.Api.Repositories;
using Wipefest.Api.Services;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.Fights;
using Wipefest.Cli.Insights;

namespace Wipefest.Api.Factories
{
    public class FightConfigFactory
    {
        private readonly WorkspaceRepository _workspaces;
        private readonly ILogger _logger;

        public FightConfigFactory(WorkspaceRepository workspaces, ILogger logger)
        {
            _workspaces = workspaces;
            _logger = logger;
        }

        public async Task<Result<FightConfig>> Create(FightConfigDto dto, bool convertToOldGroupNames = false)
        {
            if (convertToOldGroupNames)
            {
                dto.EventConfigs = dto.EventConfigs?.WithOldGroupNames() ?? new List<EventConfig>();
                dto.InsightConfigs = dto.InsightConfigs?.WithOldGroupNames() ?? new List<InsightConfig>();
            }

            var eventConfigsWithUniqueIdsResult = dto.EventConfigs.WithUniqueIds();
            if (eventConfigsWithUniqueIdsResult.IsFailure)
                return Result.Fail<FightConfig>(eventConfigsWithUniqueIdsResult.Error);

            dto.EventConfigs = eventConfigsWithUniqueIdsResult.Value;

            var workspacesResult = await GetWorkspacesFromIncludes(dto.Includes);
            if (workspacesResult.IsFailure)
                return Result.Fail<FightConfig>(workspacesResult.Error);

            var fightConfigResults = workspacesResult.Value.Select(workspace =>
            {
                var group = workspace.Key.Id;
                if (convertToOldGroupNames)
                {
                    group = group.ConvertToOldGroupName();
                }
                return Create(workspace.Code, group);
            }).ToArray();

            var combinedFightConfigResults = Result.Combine(fightConfigResults);
            if (combinedFightConfigResults.IsFailure)
            {
                return Result.Fail<FightConfig>(combinedFightConfigResults.Error);
            }

            var fightConfigs = fightConfigResults.Select(result => result.Value).ToList();

            var fightConfig = new FightConfig
            {
                EventConfigs = fightConfigs.SelectMany(f => f.EventConfigs ?? new List<EventConfig>()).Concat(dto.EventConfigs).WithOldGroupNames(),
                InsightConfigs = fightConfigs.SelectMany(f => f.InsightConfigs ?? new List<InsightConfig>()).Concat(dto.InsightConfigs).WithOldGroupNames()
            };

            return Result.Ok(fightConfig);
        }

        private async Task<Result<List<Workspace>>> GetWorkspacesFromIncludes(ICollection<string> includes)
        {
            includes =
                (includes ?? new List<string>())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .ToList();

            var workspaceKeyResults = includes.Select(WorkspaceKey.FromInclude).ToArray();

            var combinedWorkspaceKeyResult = Result.Combine(workspaceKeyResults);
            if (combinedWorkspaceKeyResult.IsFailure)
            {
                {
                    return Result.Fail<List<Workspace>>(
                        $"Failed to parse includes into workspace keys ({combinedWorkspaceKeyResult.Error})");
                }
            }

            var workspaceResultTasks = workspaceKeyResults
                .Select(result => result.Value)
                .Select(async key =>
                {
                    var maybeWorkspace = key == WorkspaceKey.LatestApproved(key.Id)
                        ? await _workspaces.GetLatestApproved(key.Id)
                        : await _workspaces.Get(key.Id, key.Revision);

                    if (maybeWorkspace.HasNoValue)
                        return Result.Fail<Workspace>($"workspace with key {key.Id}/{key.Revision} does not exist");

                    return Result.Ok(maybeWorkspace.Value);
                });

            var workspaceResults = await Task.WhenAll(workspaceResultTasks);

            var combinedWorkspaceResult = Result.Combine(workspaceResults);
            if (combinedWorkspaceResult.IsFailure)
            {
                {
                    return Result.Fail<List<Workspace>>(
                        $"Failed to retrieve workspaces from database ({combinedWorkspaceResult.Error})");
                }
            }

            return Result.Ok(workspaceResults.Select(result => result.Value).ToList());
        }

        private Result<FightConfig> Create(string code, string group)
        {
            FightConfig fightConfig;

            if (code.StartsWith("["))
            {
                try
                {
                    var eventConfigs = JsonConvert.DeserializeObject<List<EventConfig>>(code);
                    fightConfig = new FightConfig
                    {
                        EventConfigs = eventConfigs
                    };
                }
                catch (Exception ex)
                {
                    return Result.Fail<FightConfig>($"Failed to deserialize code into event configs ({ex.Message})");
                }
            }
            else
            {
                try
                {
                    fightConfig = JsonConvert.DeserializeObject<FightConfig>(code);
                }
                catch (Exception ex)
                {
                    return Result.Fail<FightConfig>($"Failed to deserialize code into fight config ({ex.Message})");
                }
            }

            fightConfig.EventConfigs = fightConfig.EventConfigs.Select(config =>
            {
                config.Group = group;
                return config;
            }).ToList();

            fightConfig.InsightConfigs = fightConfig.InsightConfigs?.Select(config =>
            {
                config.Group = group;
                return config;
            }).ToList() ?? new List<InsightConfig>();

            return Result.Ok(fightConfig);
        }
    }
}
