﻿using System;
using System.Collections.Generic;
using MongoDB.Bson.Serialization.Attributes;

namespace Wipefest.Api.Models
{
    public class Bucket
    {
        [BsonDateTimeOptions(DateOnly = true)]
        public DateTime Date { get; set; }
        public BucketCriteria Criteria { get; set; }
        public List<BucketPercentile> Percentiles { get; set; }
    }
}