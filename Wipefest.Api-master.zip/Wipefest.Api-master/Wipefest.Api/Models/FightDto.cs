﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MoreLinq;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.FightEvents;
using Wipefest.Cli.Fights;
using Wipefest.Cli.Insights;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Models
{
    public class FightDto
    {
        public ICollection<Ability> Abilities { get; }
        public ICollection<EventConfig> EventConfigs { get; }
        public ICollection<EventDto> Events { get; }
        public FightInfo Info { get; }
        public ICollection<InsightConfig> InsightConfigs { get; set; }
        public ICollection<Insight> Insights { get; }
        public RaidDto Raid { get; }
        public ReportDto Report { get; }

        public FightDto(ICollection<Ability> abilities, ICollection<EventConfig> eventConfigs, ICollection<EventDto> events, FightInfo info, ICollection<InsightConfig> insightConfigs, ICollection<Insight> insights, RaidDto raid, ReportDto report)
        {
            Abilities = abilities;
            EventConfigs = eventConfigs;
            Events = events;
            Info = info;
            InsightConfigs = insightConfigs;
            Insights = insights;
            Raid = raid;
            Report = report;
        }

        public static FightDto FromFight(Fight fight)
        {
            return new FightDto(
                fight.Abilities,
                fight.EventConfigs,
                fight.Events.Select(EventDto.FromEvent).ToList(),
                fight.Info,
                fight.InsightConfigs,
                fight.Insights,
                RaidDto.FromRaid(fight.Raid),
                ReportDto.FromReport(fight.Report)
            );
        }
    }
}
