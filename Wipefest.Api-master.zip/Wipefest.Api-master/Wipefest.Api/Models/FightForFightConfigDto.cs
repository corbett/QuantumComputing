﻿using System.Collections.Generic;
using System.Linq;
using MoreLinq;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.FightEvents;
using Wipefest.Cli.Fights;
using Wipefest.Cli.Insights;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Models
{
    public class FightForFightConfigDto
    {
        public ICollection<Ability> Abilities { get; }
        public ICollection<EventConfig> EventConfigs { get; }
        public ICollection<InsightConfig> InsightConfigs { get; }
        public ICollection<EventDto> Events { get; }
        public ICollection<Insight> Insights { get; }
        public FightInfo Info { get; }

        public FightForFightConfigDto(ICollection<Ability> abilities, ICollection<EventConfig> eventConfigs, ICollection<InsightConfig> insightConfigs, ICollection<EventDto> events, ICollection<Insight> insights, FightInfo info)
        {
            Abilities = abilities;
            EventConfigs = eventConfigs;
            InsightConfigs = insightConfigs;
            Events = events;
            Insights = insights;
            Info = info;
        }

        public static FightForFightConfigDto FromFight(Fight fight)
        {
            return new FightForFightConfigDto(
                fight.Abilities,
                fight.EventConfigs,
                fight.InsightConfigs,
                fight.Events.Select(EventDto.FromEvent).ToList(),
                fight.Insights,
                fight.Info
            );
        }
    }
}