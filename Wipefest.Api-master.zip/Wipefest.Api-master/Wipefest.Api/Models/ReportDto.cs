﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Models
{
    public class ReportDto
    {
        public string Id { get; }
        public string Owner { get; }
        public string Title { get; }
        public long Start { get; }
        public long End { get; }
        public ICollection<FightInfo> Fights { get; }
        public ICollection<ActorDto> Friendlies { get; }
        public ICollection<PetActorDto> FriendlyPets { get; }
        public ICollection<ActorDto> Enemies { get; }

        public ReportDto(string id, string owner, string title, long start, long end, ICollection<FightInfo> fights, ICollection<ActorDto> friendlies, ICollection<PetActorDto> friendlyPets, ICollection<ActorDto> enemies)
        {
            Id = id;
            Owner = owner;
            Title = title;
            Start = start;
            End = end;
            Fights = fights;
            Friendlies = friendlies;
            FriendlyPets = friendlyPets;
            Enemies = enemies;
        }

        public static ReportDto FromReport(Report report)
        {
            var bossFights = report.Fights.Where(x => x.Boss > 0).ToList();
            var bossFightIds = bossFights.Select(x => x.Id).ToList();

            return new ReportDto(
                report.Id,
                report.Owner,
                report.Title,
                report.Start,
                report.End,
                bossFights,
                FilterActorsToFights(report.Friendlies, bossFightIds).Select(ActorDto.FromActor).ToList(),
                FilterPetActorsToFights(report.FriendlyPets, bossFightIds).Select(PetActorDto.FromPetActor).ToList(),
                FilterActorsToFights(report.Enemies, bossFightIds).Select(ActorDto.FromActor).ToList()
            );

            ICollection<Actor> FilterActorsToFights(IEnumerable<Actor> actors, ICollection<int> fightIds)
            {
                var filteredActors = actors
                    .Select(actor =>
                    {
                        actor.Fights = actor.Fights.Where(x => fightIds.Contains(x.Id)).ToList();
                        return actor;
                    })
                    .Where(actor => actor.Fights.Any())
                    .ToList();

                return filteredActors;
            }

            ICollection<PetActor> FilterPetActorsToFights(IEnumerable<PetActor> actors, ICollection<int> fightIds)
            {
                var filteredActors = actors
                    .Select(actor =>
                    {
                        actor.Fights = actor.Fights.Where(x => fightIds.Contains(x.Id)).ToList();
                        return actor;
                    })
                    .Where(actor => actor.Fights.Any())
                    .ToList();

                return filteredActors;
            }
        }
    }
}
