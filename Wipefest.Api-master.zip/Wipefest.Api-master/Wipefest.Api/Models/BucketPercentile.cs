﻿namespace Wipefest.Api.Models
{
    public class BucketPercentile
    {
        public int Percentile { get; set; }
        public decimal BottomValue { get; set; }
        public decimal TopValue { get; set; }
    }
}