﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Wipefest.Api.Models
{
    public class Statistic
    {
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        public DateTime Timestamp { get; set; }
        public string ReportId { get; set; }
        public int FightId { get; set; }
        public string InsightId { get; set; }
        public string InsightGroup { get; set; }
        public int Boss { get; set; }
        public string Name { get; set; }
        public decimal Value { get; set; }
        public bool HigherIsBetter { get; set; }
        public int RaidSize { get; set; }
        public decimal RaidItemLevel { get; set; }
        [BsonRepresentation(BsonType.String)]
        public Difficulty Difficulty { get; set; }
        public long Duration { get; set; }
    }

    public enum Difficulty
    {
        Normal = 3,
        Heroic = 4,
        Mythic = 5
    }
}
