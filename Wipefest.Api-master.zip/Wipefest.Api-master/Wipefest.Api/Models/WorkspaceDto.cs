﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.FightEvents;
using Wipefest.Cli.Insights;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Models
{
    public class WorkspaceDto
    {
        public ICollection<TestCaseDto> TestCases { get; set; }
        public string Code { get; set; }
        public FightInfo FightInfo { get; set; }
        public ICollection<EventDto> Events { get; set; }
        public ICollection<Insight> Insights { get; set; }
        public ICollection<EventConfig> Configs { get; set; }
        public ICollection<Ability> Abilities { get; set; }
    }
}
