﻿namespace Wipefest.Api.Models
{
    public class TestCaseDto
    {
        public string Name { get; set; }
        public string ReportId { get; set; }
        public int FightId { get; set; }
    }
}