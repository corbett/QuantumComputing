﻿using System;
using System.Collections.Generic;
using System.Linq;
using CSharpFunctionalExtensions;
using Newtonsoft.Json;
using Serilog;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.Fights;
using Wipefest.Cli.Insights;

namespace Wipefest.Api.Models
{
    public class FightConfigDto
    {
        public ICollection<string> Includes { get; set; }
        public ICollection<EventConfig> EventConfigs { get; set; }
        public ICollection<InsightConfig> InsightConfigs { get; set; }

        public static Result<FightConfigDto> FromWorkspace(Workspace workspace)
        {
            var code = workspace.Code;
            var group = workspace.Key.Id;

            FightConfigDto fightConfigDto;

            if (code.StartsWith("["))
            {
                try
                {
                    var eventConfigs = JsonConvert.DeserializeObject<List<EventConfig>>(code);
                    fightConfigDto = new FightConfigDto
                    {
                        EventConfigs = eventConfigs
                    };
                }
                catch (Exception ex)
                {
                    return Result.Fail<FightConfigDto>($"Failed to deserialize code into event configs ({ex.Message})");
                }
            }
            else
            {
                try
                {
                    fightConfigDto = JsonConvert.DeserializeObject<FightConfigDto>(code);
                }
                catch (Exception ex)
                {
                    return Result.Fail<FightConfigDto>($"Failed to deserialize code into fight config ({ex.Message})");
                }
            }

            fightConfigDto.EventConfigs = fightConfigDto.EventConfigs.Select(config =>
            {
                config.Group = group;
                return config;
            }).ToList();

            fightConfigDto.InsightConfigs = fightConfigDto.InsightConfigs?.Select(config =>
            {
                config.Group = group;
                return config;
            }).ToList() ?? new List<InsightConfig>();

            return Result.Ok(fightConfigDto);
        }

        public FightConfigDto AppendOldFormatIncludes(IEnumerable<string> oldIncludes)
        {
            var newIncludes = oldIncludes.Select(oldInclude =>
            {
                oldInclude = oldInclude.Replace("general/", "");

                var parts = oldInclude.Split('/');
                if (parts.Length > 1 && parts[0] == parts[1])
                    return parts[0];

                return oldInclude.Replace("/", "-");
            });

            return new FightConfigDto
            {
                EventConfigs = EventConfigs,
                InsightConfigs = InsightConfigs,
                Includes = Includes.Concat(newIncludes).ToList()
            };
        }
    }
}
