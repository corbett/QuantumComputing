﻿using System.Collections.Generic;
using System.Linq;
using Wipefest.Cli.Raid;

namespace Wipefest.Api.Models
{
    public class RaidDto
    {
        public decimal ItemLevel { get; }
        public ICollection<Player> Players { get; }

        public RaidDto(decimal itemLevel, ICollection<Player> players)
        {
            ItemLevel = itemLevel;
            Players = players;
        }

        public static RaidDto FromRaid(Raid raid)
        {
            return new RaidDto(raid.ItemLevel, raid.Players);
        }
    }
}