﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Wipefest.Api.Models
{
    public class FightAndStatisticsDto
    {
        public List<Statistic> Statistics { get; set; }
        public FightForFightConfigDto Fight { get; set; }
    }
}
