﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.FightEvents;
using Wipefest.Cli.Insights;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Models
{
    public class Workspace
    {
        [BsonId]
        public WorkspaceKey Key { get; protected set; }
        public bool Approved { get; protected set; }
        public ICollection<TestCaseDto> TestCases { get; protected set; }
        public string Code { get; protected set; }
        public FightInfo FightInfo { get; protected set; }
        public ICollection<EventDto> Events { get; protected set; }
        public ICollection<Insight> Insights { get; protected set; }
        public ICollection<EventConfig> Configs { get; protected set; }
        public ICollection<Ability> Abilities { get; protected set; }

        public Workspace(
            WorkspaceKey key,
            bool approved = false,
            ICollection<TestCaseDto> testCases = null,
            string code = null,
            FightInfo fightInfo = null,
            ICollection<EventDto> events = null,
            ICollection<Insight> insights = null,
            ICollection<EventConfig> configs = null,
            ICollection<Ability> abilities = null
        )
        {
            Key = key;
            Approved = approved;
            TestCases = testCases ?? new List<TestCaseDto>();
            Code = code ?? "{\n  \"eventConfigs\": [\n    // What events would you love to see in Wipefest?\n  ],\n  \"insightConfigs\": [\n    // What insights can we build from these events?\n  ]\n}";
            FightInfo = fightInfo;
            Events = events ?? new List<EventDto>();
            Insights = insights ?? new List<Insight>();
            Configs = configs ?? new List<EventConfig>();
            Abilities = abilities ?? new List<Ability>();
        }

        public static Workspace FromDto(string id, int revision, WorkspaceDto dto)
        {
            return new Workspace(
                new WorkspaceKey(id, revision),
                false,
                dto.TestCases,
                dto.Code,
                dto.FightInfo,
                dto.Events,
                dto.Insights,
                dto.Configs,
                dto.Abilities);
        }

        public Workspace NormalizeCodeFormat()
        {
            if (Code.StartsWith("["))
            {
                var lines = new List<string> { "{" }
                    .Concat(Code
                        .Replace("\n", "\r\n")
                        .Split("\r\n")
                        .Select(line => "  " + line))
                    .ToList();

                lines[1] = "  \"eventConfigs\": [";

                lines.Add("}");

                var workspace = new Workspace(
                    Key,
                    Approved,
                    TestCases,
                    string.Join("\n", lines),
                    FightInfo,
                    Events,
                    Insights,
                    Configs,
                    Abilities);

                return workspace;
            }

            return new Workspace(Key, Approved, TestCases, Code, FightInfo, Events, Insights, Configs, Abilities);
        }

        public Workspace Rename(string newId)
        {
            return new Workspace(new WorkspaceKey(newId, 0), Approved, TestCases, Code, FightInfo, Events, Insights, Configs, Abilities);
        }
    }

    public class WorkspaceKey : ValueObject
    {
        public string Id { get; }
        public int Revision { get; }

        public WorkspaceKey(string id, int revision)
        {
            Id = id;
            Revision = revision;
        }

        public static WorkspaceKey LatestApproved(string id) => new WorkspaceKey(id, int.MaxValue);

        public static Result<WorkspaceKey> FromInclude(string include)
        {
            var parts = include.Split('/');
            if (parts.Length > 2)
            {
                return Result.Fail<WorkspaceKey>("Include can only have 1 '/'");
            }

            var id = parts[0];
            if (parts.Length == 2)
            {
                var revisionIsInteger = int.TryParse(parts[1], out var revision);
                if (!revisionIsInteger)
                {
                    return Result.Fail<WorkspaceKey>("Revision must be an integer");
                }
            }

            return Result.Ok(LatestApproved(id));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Id;
            yield return Revision;
        }
    }
}
