﻿using System.Collections.Generic;
using System.Linq;
using Wipefest.Cli.FightEvents;

namespace Wipefest.Api.Models
{
    public class EventDto
    {
        public int? AbilityGuid { get; set; }
        public ICollection<EventDto> ChildEvents { get; set; }
        public string ConfigId { get; set; }
        public string ConfigGroup { get; set; }
        public string Details { get; set; }
        public bool IsFriendly { get; set; }
        public string MinutesAndSeconds { get; set; }
        public bool? IsSubtitle { get; set; }
        public string TableTitle { get; set; }
        public long Timestamp { get; set; }
        public string Title { get; set; }
        public string Type { get; set; }

        public EventDto(int? abilityGuid, ICollection<EventDto> childEvents, string configId, string configGroup, string details, bool isFriendly, string minutesAndSeconds, bool? isSubtitle, string tableTitle, long timestamp, string title, string type)
        {
            AbilityGuid = abilityGuid;
            ChildEvents = childEvents ?? new List<EventDto>();
            ConfigId = configId;
            ConfigGroup = configGroup;
            Details = details;
            IsFriendly = isFriendly;
            MinutesAndSeconds = minutesAndSeconds;
            IsSubtitle = isSubtitle;
            TableTitle = tableTitle;
            Timestamp = timestamp;
            Title = title;
            Type = type;
        }

        public static EventDto FromEvent(FightEvent @event)
        {
            return new EventDto(
                @event.Ability?.Guid ?? @event.KillingBlow?.Guid,
                @event.ChildEvents?.Select(FromEvent).ToList(),
                @event.Config?.Id,
                @event.Config?.Group,
                @event.Details,
                @event.IsFriendly,
                @event.MinutesAndSeconds,
                @event.Subtitle,
                @event.TableTitle,
                @event.Timestamp,
                @event.Title,
                @event.Config?.EventType
            );
        }
    }
}