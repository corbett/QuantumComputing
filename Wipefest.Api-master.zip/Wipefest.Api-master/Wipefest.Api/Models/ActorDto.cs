﻿using System.Collections.Generic;
using System.Linq;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Models
{
    public class ActorDto
    {
        public ICollection<int> FightIds { get; }
        public int Id { get; }
        public int Guid { get; }
        public string Name { get; }
        public string Type { get; }
        public int Instance { get; }

        public ActorDto(ICollection<int> fightIds, int id, int guid, string name, string type, int instance)
        {
            FightIds = fightIds;
            Id = id;
            Guid = guid;
            Name = name;
            Type = type;
            Instance = instance;
        }

        public static ActorDto FromActor(Actor actor)
        {
            return new ActorDto(
                actor.Fights.Select(x => x.Id).ToList(),
                actor.Id,
                actor.Guid,
                actor.Name,
                actor.Type,
                actor.Instance
            );
        }
    }
}