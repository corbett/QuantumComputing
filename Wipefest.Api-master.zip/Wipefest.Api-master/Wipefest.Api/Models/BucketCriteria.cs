﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace Wipefest.Api.Models
{
    public class BucketCriteria
    {
        public string InsightId { get; set; }
        public string InsightGroup { get; set; }
        public string Name { get; set; }
        public int Boss { get; set; }
        [BsonRepresentation(BsonType.String)]
        public Difficulty Difficulty { get; set; }
        public bool HigherIsBetter { get; set; }
    }
}