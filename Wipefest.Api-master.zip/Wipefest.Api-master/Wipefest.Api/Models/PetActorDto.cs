﻿using System.Collections.Generic;
using System.Linq;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Models
{
    public class PetActorDto : ActorDto
    {
        public int PetOwner { get; }

        public PetActorDto(ICollection<int> fightIds, int id, int guid, string name, string type, int instance, int petOwner) : base(fightIds, id, guid, name, type, instance)
        {
            PetOwner = petOwner;
        }

        public static PetActorDto FromPetActor(PetActor petActor)
        {
            return new PetActorDto(
                petActor.Fights.Select(x => x.Id).ToList(),
                petActor.Id,
                petActor.Guid,
                petActor.Name,
                petActor.Type,
                petActor.Instance,
                petActor.PetOwner
            );
        }
    }
}