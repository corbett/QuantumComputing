﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Factories;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Models;
using Wipefest.Api.Services;
using Wipefest.Cli;
using Wipefest.Cli.Fights;

namespace Wipefest.Api.Controllers
{
    public class StatisticController : Controller
    {
        private readonly FightService _fightService;
        private readonly StatisticService _statisticService;
        private readonly ApiKeyValidator _apiKeyValidator;
        private readonly FightConfigService _fightConfigService;
        private readonly FightConfigFactory _fightConfigFactory;

        public StatisticController(FightService fightService, StatisticService statisticService,
            ApiKeyValidator apiKeyValidator, FightConfigService fightConfigService, FightConfigFactory fightConfigFactory)
        {
            _fightService = fightService;
            _statisticService = statisticService;
            _apiKeyValidator = apiKeyValidator;
            _fightConfigService = fightConfigService;
            _fightConfigFactory = fightConfigFactory;
        }

        [HttpPost("report/{reportId}/fight/{fightId}/forFightConfig/statistics")]
        [SwaggerOperation("SetStatisticsForFightConfig")]
        [ProducesResponseType(typeof(FightAndStatisticsDto), 200)]
        public async Task<IActionResult> Set(
            [FromHeader(Name = "x-api-key")] string apiKey,
            string reportId,
            int fightId,
            [FromBody] FightConfigDto fightConfigDto)
        {
            if (!_apiKeyValidator.IsAdmin(apiKey))
                return StatusCode(403);

            var fightConfigResult = await _fightConfigFactory.Create(fightConfigDto);
            if (fightConfigResult.IsFailure)
                return BadRequest(fightConfigResult.Error);

            var fightConfig = fightConfigResult.Value;

            var dtoResult = await GetFightAndStatisticsDto(reportId, fightId, fightConfig);

            if (dtoResult.IsFailure)
                return BadRequest(dtoResult.Error);

            return Ok(dtoResult.Value);
        }

        [HttpPost("report/{reportId}/fight/{fightId}/statistics")]
        [SwaggerOperation("SetStatistics")]
        [ProducesResponseType(typeof(FightAndStatisticsDto), 200)]
        public async Task<IActionResult> Set(
            [FromHeader(Name = "x-api-key")] string apiKey,
            string reportId,
            int fightId,
            string group)
        {
            if (!_apiKeyValidator.IsAdmin(apiKey))
                return StatusCode(403);

            var fightConfigResult = await _fightConfigService.Get(group);

            if (fightConfigResult.IsFailure)
                return BadRequest(fightConfigResult.Error);

            var fightConfig = fightConfigResult.Value;

            var dtoResult = await GetFightAndStatisticsDto(reportId, fightId, fightConfig);

            if (dtoResult.IsFailure)
                return BadRequest(dtoResult.Error);

            return Ok(dtoResult.Value);
        }

        [HttpPost("/statistics/buckets")]
        [SwaggerOperation("CalculateAndStoreStatisticsBuckets")]
        [ProducesResponseType(typeof(void), 200)]
        public async Task<IActionResult> CalculateAndStoreBuckets([FromHeader(Name = "x-api-key")] string apiKey, DateTime? date = null)
        {
            if (!_apiKeyValidator.IsAdmin(apiKey))
                return StatusCode(403);

            var buckets = await _statisticService.CalculateAndStoreBuckets(date ?? DateTime.UtcNow.AddDays(1).Date);

            return Ok(buckets);
        }

        private async Task<Result<FightAndStatisticsDto>> GetFightAndStatisticsDto(string reportId, int fightId, FightConfig fightConfig)
        {
            fightConfig = TrimFightConfig(fightConfig);

            var fightResult = await _fightService.GetForFightConfig(reportId, fightId, fightConfig);

            if (!fightResult.IsSuccess)
                return Result.Fail<FightAndStatisticsDto>(fightResult.Error);

            var fight = fightResult.Value;

            if (!fight.Info.Kill)
                return Result.Fail<FightAndStatisticsDto>("Can only set statistics for successful kills");

            var statistics = await _statisticService.Set(fightResult.Value, fightConfig.InsightConfigs);

            return Result.Ok(new FightAndStatisticsDto
            {
                Statistics = statistics,
                Fight = FightForFightConfigDto.FromFight(fightResult.Value)
            });
        }

        private static FightConfig TrimFightConfig(FightConfig fightConfig)
        {
            var insightConfigs = fightConfig.InsightConfigs.Where(i => i.Statistics != null && i.Statistics.Any()).ToList();
            var requires = insightConfigs.SelectMany(i => i.Require.ExtractRequire()).ToList();
            var eventConfigs =
                fightConfig.EventConfigs.Where(e => requires.Any(r => r.Group == e.Group && r.Ids.Contains(e.Id))).ToList();

            return new FightConfig
            {
                EventConfigs = eventConfigs,
                InsightConfigs = insightConfigs
            };
        }
    }
}
