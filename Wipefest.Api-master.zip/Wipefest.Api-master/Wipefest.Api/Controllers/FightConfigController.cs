﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Factories;
using Wipefest.Api.Models;
using Wipefest.Api.Repositories;
using Wipefest.Cli.Fights;

namespace Wipefest.Api.Controllers
{
    public class FightConfigController : Controller
    {
        private readonly WorkspaceRepository _workspaces;
        private readonly FightConfigFactory _fightConfigFactory;

        public FightConfigController(WorkspaceRepository workspaces, FightConfigFactory fightConfigFactory)
        {
            _workspaces = workspaces;
            _fightConfigFactory = fightConfigFactory;
        }

        /// <summary>
        /// Get latest approved fight config for a group
        /// </summary>
        /// <param name="group">The group to retrieve an approved fight config for</param>
        /// <returns>The approved fight config</returns>
        [HttpGet("fightConfig/{group}")]
        [SwaggerOperation("GetLatestApprovedFightConfig")]
        [ProducesResponseType(typeof(FightConfig), 200)]
        public async Task<IActionResult> GetLatestApproved(string group)
        {
            var maybeWorkspace = await _workspaces.GetLatestApproved(group);

            if (maybeWorkspace.HasNoValue)
                return NotFound();

            var workspace = maybeWorkspace.Value;

            var fightConfigDtoResult = FightConfigDto.FromWorkspace(workspace);

            if (fightConfigDtoResult.IsFailure)
                return BadRequest(fightConfigDtoResult.Error);

            var fightConfigResult = await _fightConfigFactory.Create(fightConfigDtoResult.Value);

            if (fightConfigResult.IsFailure)
                return BadRequest(fightConfigResult.Error);

            return Ok(fightConfigResult.Value);
        }
    }
}
