﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Models;
using Wipefest.Cli;
using Wipefest.Cli.Encounters;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Controllers
{
    public class EncountersController : Controller
    {
        private readonly WipefestCli _wipefest;

        public EncountersController(WipefestCli wipefest)
        {
            _wipefest = wipefest;
        }

        /// <summary>
        /// Retrieve encounters supported by Wipefest
        /// </summary>
        /// <returns></returns>
        [HttpGet("encounters")]
        [SwaggerOperation("GetEncounters")]
        [ProducesResponseType(typeof(List<Encounter>), 200)]
        public async Task<IActionResult> Get()
        {
            var result = await _wipefest.GetEncounters();

            return result.ToActionResult();
        }
    }
}
