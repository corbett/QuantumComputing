﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Models;
using Wipefest.Cli;
using Wipefest.Cli.Guilds;

namespace Wipefest.Api.Controllers
{
    public class GuildController : Controller
    {
        private readonly WipefestCli _wipefest;

        public GuildController(WipefestCli wipefest)
        {
            _wipefest = wipefest;
        }

        /// <summary>
        /// Retrieve a guild's reports
        /// </summary>
        /// <param name="region">The region that the guild's realm is located within (e.g. US, EU, etc)</param>
        /// <param name="realm">The realm that the guild is on</param>
        /// <param name="name">The name of the guild</param>
        /// <param name="zone">The Warcraft Logs zone id to filter reports to</param>
        /// <returns></returns>
        [HttpGet("/guild/{region}/{realm}/{name}/reports")]
        [SwaggerOperation("GetGuildReports")]
        [ProducesResponseType(typeof(List<GuildReport>), 200)]
        public async Task<IActionResult> GetReports(string region, string realm, string name, int? zone = null)
        {
            var result = await _wipefest.GetGuildReports(region, realm, name);

            if (zone == null)
                return result.ToActionResult();
            
            return result.ToActionResult(reports => reports.Where(x => x.Zone == zone));
        }
    }
}
