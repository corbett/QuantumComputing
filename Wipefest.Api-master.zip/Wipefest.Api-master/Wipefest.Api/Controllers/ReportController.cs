﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Models;
using Wipefest.Cli;
using Wipefest.Cli.Reports;

namespace Wipefest.Api.Controllers
{
    public class ReportController : Controller
    {
        private readonly WipefestCli _wipefest;

        public ReportController(WipefestCli wipefest)
        {
            _wipefest = wipefest;
        }

        /// <summary>
        /// Retrieve a Warcraft Logs report by it's id
        /// </summary>
        /// <param name="reportId">The Warcraft Logs report id, which can be found in the Warcraft Logs URL to that report (after "/reports/"). For example: vLaYkKjMJCZ1WfrQ.</param>
        /// <returns></returns>
        [HttpGet("report/{reportId}")]
        [SwaggerOperation("GetReport")]
        [ProducesResponseType(typeof(Report), 200)]
        public async Task<IActionResult> Get(string reportId)
        {
            var result = await _wipefest.GetReport(reportId);

            return result.ToActionResult(ReportDto.FromReport);
        }
    }
}
