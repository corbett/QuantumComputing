﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Models;
using Wipefest.Cli;
using Wipefest.Cli.Encounters;
using Wipefest.Cli.Reports;
using Wipefest.Cli.Specializations;

namespace Wipefest.Api.Controllers
{
    public class SpecializationsController : Controller
    {
        private readonly WipefestCli _wipefest;

        public SpecializationsController(WipefestCli wipefest)
        {
            _wipefest = wipefest;
        }

        /// <summary>
        /// Retrieve specializations supported by Wipefest
        /// </summary>
        /// <returns></returns>
        [HttpGet("specializations")]
        [SwaggerOperation("GetSpecializations")]
        [ProducesResponseType(typeof(List<Specialization>), 200)]
        public async Task<IActionResult> Get()
        {
            var result = await _wipefest.GetSpecializations();

            return result.ToActionResult();
        }
    }
}
