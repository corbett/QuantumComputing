﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Models;
using Wipefest.Cli;
using Wipefest.Cli.Characters;

namespace Wipefest.Api.Controllers
{
    public class CharacterController : Controller
    {
        private readonly WipefestCli _wipefest;

        public CharacterController(WipefestCli wipefest)
        {
            _wipefest = wipefest;
        }

        /// <summary>
        /// Retrieve a character's parses
        /// </summary>
        /// <param name="region">The region that the character's realm is located within (e.g. US, EU, etc)</param>
        /// <param name="realm">The realm that the character is on</param>
        /// <param name="name">The name of the character</param>
        /// <param name="zone">(Required) The Warcraft Logs zone id to get parses for (e.g. 17 = Antorus, the Burning Throne)</param>
        /// <param name="partitions">(Required) The Warcraft Logs zone partitions to get parses for</param>
        /// <returns></returns>
        [HttpGet("/character/{region}/{realm}/{name}/parses")]
        [SwaggerOperation("GetCharacterParses")]
        [ProducesResponseType(typeof(List<ParsesForEncounter>), 200)]
        public async Task<IActionResult> GetParses(string region, string realm, string name, int zone, int[] partitions)
        {
            if (zone <= 0)
                return BadRequest("'zone' is required.");
            if (partitions.Length == 0)
                return BadRequest("'partitions' is required.");

            var result = await _wipefest.GetCharacterParses(region, realm, name, zone, partitions);

            return result.ToActionResult();
        }
    }
}
