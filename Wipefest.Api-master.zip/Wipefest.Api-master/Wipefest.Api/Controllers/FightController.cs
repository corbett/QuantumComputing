﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Models;
using Wipefest.Api.Services;
using Wipefest.Cli;

namespace Wipefest.Api.Controllers
{
    public class FightController : Controller
    {
        private readonly WipefestCli _wipefest;
        private readonly FightService _fightService;

        public FightController(WipefestCli wipefest, FightService fightService)
        {
            _wipefest = wipefest;
            _fightService = fightService;
        }

        /// <summary>
        /// Retrieve a Wipefest fight by its Warcraft Logs report id and fight id
        /// </summary>
        /// <param name="reportId">The Warcraft Logs report id, which can be found in the Warcraft Logs URL to that report (after "/reports/"). For example: vLaYkKjMJCZ1WfrQ.</param>
        /// <param name="fightId">The Warcraft Logs fight id, which can be found in the Warcraft Logs URL to that fight (after "fight=")</param>
        /// <param name="group">The group to look for approved fight configs for before falling back</param>
        /// <param name="markupFormat">The format to pre-parse strings into (Markup/Text/Html). Defaults to Markup.</param>
        /// <param name="includes">Additional event config files to include (e.g. [ "priest/priest", "priest/holy", "general/focus", "general/healer" ])</param>
        /// <returns></returns>
        [HttpGet("report/{reportId}/fight/{fightId}")]
        [SwaggerOperation("GetFight")]
        [ProducesResponseType(typeof(FightDto), 200)]
        public async Task<IActionResult> Get(
            string reportId,
            int fightId,
            string group,
            MarkupParsingFormat markupFormat = MarkupParsingFormat.Markup,
            ICollection<string> includes = null)
        {
            var fightResult = await _fightService.Get(reportId, fightId, group, markupFormat, includes);

            return fightResult.ToActionResult(FightDto.FromFight);
        }

        /// <summary>
        /// Retrieve a Wipefest fight by its Warcraft Logs report id and fight id, with a specific fight config
        /// </summary>
        /// <param name="reportId">The Warcraft Logs report id, which can be found in the Warcraft Logs URL to that report (after "/reports/"). For example: vLaYkKjMJCZ1WfrQ.</param>
        /// <param name="fightId">The Warcraft Logs fight id, which can be found in the Warcraft Logs URL to that fight (after "fight=")</param>
        /// <param name="markupFormat">The format to pre-parse strings into (Markup/Text/Html). Defaults to Markup.</param>
        /// <param name="fightConfigDto">The exact fightConfig. This will override any event/insight configs inside of default includes.</param>
        /// <returns></returns>
        [HttpPost("report/{reportId}/fight/{fightId}/forFightConfig")]
        [SwaggerOperation("GetFightForFightConfig")]
        [ProducesResponseType(typeof(FightForFightConfigDto), 200)]
        public async Task<IActionResult> GetForFightConfig(
            string reportId,
            int fightId,
            [FromBody] FightConfigDto fightConfigDto,
            MarkupParsingFormat markupFormat = MarkupParsingFormat.Markup)
        {
            var result = await _fightService.GetForFightConfig(reportId, fightId, fightConfigDto, markupFormat);

            return result.ToActionResult(FightForFightConfigDto.FromFight);
        }

        /// <summary>
        /// Retrieve raid information for a specific fight by its Warcraft Logs report id and fight id
        /// </summary>
        /// <param name="reportId">The Warcraft Logs report id, which can be found in the Warcraft Logs URL to that report (after "/reports/"). For example: vLaYkKjMJCZ1WfrQ.</param>
        /// <param name="fightId">The Warcraft Logs fight id, which can be found in the Warcraft Logs URL to that fight (after "fight=")</param>
        /// <returns></returns>
        [HttpGet("report/{reportId}/fight/{fightId}/raid")]
        [SwaggerOperation("GetRaid")]
        [ProducesResponseType(typeof(RaidDto), 200)]
        public async Task<IActionResult> GetRaid(string reportId, int fightId)
        {
            var result = await _wipefest.GetRaid(reportId, fightId);

            return result.ToActionResult(RaidDto.FromRaid);
        }
    }
}