﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;
using Wipefest.Api.Infrastructure;
using Wipefest.Api.Models;
using Wipefest.Api.Repositories;
using Wipefest.Api.Services;
using Wipefest.Cli;
using Wipefest.Cli.Guilds;

namespace Wipefest.Api.Controllers
{
    public class WorkspaceController : Controller
    {
        private readonly ApiKeyValidator _apiKeyValidator;
        private readonly WorkspaceRepository _workspaces;
        private readonly WorkspaceSeeder _workspaceSeeder;

        /// <summary>
        /// Create and retrieve workspaces
        /// </summary>
        public WorkspaceController(ApiKeyValidator apiKeyValidator, WorkspaceRepository workspaces, WorkspaceSeeder workspaceSeeder)
        {
            _apiKeyValidator = apiKeyValidator;
            _workspaces = workspaces;
            _workspaceSeeder = workspaceSeeder;
        }

        /// <summary>
        /// Create a new workspace
        /// </summary>
        /// <param name="workspaceDto">The workspace to create</param>
        /// <returns></returns>
        [HttpPost("workspace")]
        [SwaggerOperation("CreateWorkspace")]
        [ProducesResponseType(typeof(Workspace), 201)]
        public async Task<IActionResult> Create([FromBody] WorkspaceDto workspaceDto)
        {
            var workspace = await _workspaces.Create(workspaceDto);

            return StatusCode(201, workspace);
        }

        /// <summary>
        /// Update a workspace
        /// </summary>
        /// <param name="id">The id of the workspace to update</param>
        /// <param name="workspaceDto">The workspace data for the update</param>
        /// <returns></returns>
        [HttpPut("workspace/{id}")]
        [SwaggerOperation("UpdateWorkspace")]
        [ProducesResponseType(typeof(Workspace), 200)]
        public async Task<IActionResult> Update(string id, [FromBody] WorkspaceDto workspaceDto)
        {
            var workspace = await _workspaces.Update(id, workspaceDto);

            return StatusCode(200, workspace);
        }

        /// <summary>
        /// Retrieve a workspace with a given ID and revision
        /// </summary>
        /// <param name="id">The ID of the workspace to retrieve</param>
        /// <param name="revision">The revision of the workspace to retrieve</param>
        /// <returns></returns>
        [HttpGet("workspace/{id}/{revision}")]
        [SwaggerOperation("GetWorkspace")]
        [ProducesResponseType(typeof(Workspace), 200)]
        public async Task<IActionResult> Get(string id, int revision)
        {
            var maybeWorkspace = await _workspaces.Get(id, revision);

            if (maybeWorkspace.HasNoValue)
                return NotFound();

            var workspace = maybeWorkspace.Value.NormalizeCodeFormat();

            return Ok(workspace);
        }

        /// <summary>
        /// Retrieve the latest approved (or latest if none approved) workspace with a given ID
        /// </summary>
        /// <param name="id">The ID of the workspace to retrieve</param>
        /// <returns></returns>
        [HttpGet("workspace/{id}/latestApprovedOrLatest")]
        [SwaggerOperation("GetLatestApprovedOrLatestWorkspace")]
        [ProducesResponseType(typeof(Workspace), 200)]
        public async Task<IActionResult> GetLatestApprovedOrLatest(string id)
        {
            var maybeApprovedWorkspace = await _workspaces.GetLatestApproved(id);

            if (maybeApprovedWorkspace.HasValue)
                return Ok(maybeApprovedWorkspace.Value.NormalizeCodeFormat());

            var maybeWorkspace = await _workspaces.GetLatest(id);

            if (maybeWorkspace.HasNoValue)
                return NotFound();

            return Ok(maybeWorkspace.Value.NormalizeCodeFormat());
        }

        /// <summary>
        /// Copy a workspace from one id/revision to another id
        /// </summary>
        /// <param name="sourceId">The id of the workspace to copy from</param>
        /// <param name="sourceRevision">The revision of the workspace to copy from</param>
        /// <param name="destinationId">The id of the workspace to create</param>
        /// <param name="apiKey">x-api-key header</param>
        /// <returns>The new workspace</returns>
        [HttpPost("workspace/{sourceId}/{sourceRevision}/copyTo/{destinationId}")]
        [SwaggerOperation("CopyWorkspace")]
        [ProducesResponseType(typeof(Workspace), 201)]
        public async Task<IActionResult> Copy(string sourceId, int sourceRevision, string destinationId, [FromHeader(Name = "x-api-key")] string apiKey)
        {
            if (!_apiKeyValidator.IsAdmin(apiKey))
                return StatusCode(403);

            var newWorkspaceResult = await _workspaces.Copy(sourceId, sourceRevision, destinationId);

            if (newWorkspaceResult.IsFailure)
                return BadRequest(newWorkspaceResult.Error);

            return Ok(newWorkspaceResult.Value);
        }

        /// <summary>
        /// Approves a workspace
        /// </summary>
        /// <param name="id">The id of the workspace to approve</param>
        /// <param name="revision">The revision of the workspace to approve</param>
        /// <param name="apiKey">x-api-key header</param>
        /// <returns></returns>
        [HttpPost("workspace/approve")]
        [SwaggerOperation("ApproveWorkspace")]
        [ProducesResponseType(typeof(void), 200)]
        public async Task<IActionResult> Approve(
            string id, int revision,
            [FromHeader(Name = "x-api-key")] string apiKey)
        {
            if (!_apiKeyValidator.IsAdmin(apiKey))
                return StatusCode(403);

            var maybeWorkspace = await _workspaces.Get(id, revision);
            if (maybeWorkspace.HasNoValue)
                return NotFound();

            await _workspaces.Approve(id, revision);

            return Ok();
        }

        /// <summary>
        /// Unapproves a workspace
        /// </summary>
        /// <param name="id">The id of the workspace to unapprove</param>
        /// <param name="revision">The revision of the workspace to unapprove</param>
        /// <param name="apiKey">x-api-key header</param>
        /// <returns></returns>
        [HttpPost("workspace/unapprove")]
        [SwaggerOperation("UnapproveWorkspace")]
        [ProducesResponseType(typeof(void), 200)]
        public async Task<IActionResult> Unapprove(
            string id, int revision,
            [FromHeader(Name = "x-api-key")] string apiKey)
        {
            if (!_apiKeyValidator.IsAdmin(apiKey))
                return StatusCode(403);

            var maybeWorkspace = await _workspaces.Get(id, revision);
            if (maybeWorkspace.HasNoValue)
                return NotFound();

            await _workspaces.Unapprove(id, revision);

            return Ok();
        }

        /// <summary>
        /// Seeds workspaces from the old Wipefest.EventConfigs GitHub repository.
        /// If any workspaces with the corresponding keys already exist, then they are not replaced or deleted.
        /// Also seeds empty workspaces for the Uldir raid.
        /// </summary>
        /// <param name="apiKey">x-api-key header</param>
        /// <returns>The number of workspaces that were created</returns>
        [HttpPost("workspace/seed")]
        [SwaggerOperation("SeedWorkspaces")]
        [ProducesResponseType(typeof(void), 200)]
        public async Task<IActionResult> Seed([FromHeader(Name = "x-api-key")] string apiKey)
        {
            if (!_apiKeyValidator.IsAdmin(apiKey))
                return StatusCode(403);

            var totalCreated = await _workspaceSeeder.Seed();

            return Ok(totalCreated);
        }
    }
}
