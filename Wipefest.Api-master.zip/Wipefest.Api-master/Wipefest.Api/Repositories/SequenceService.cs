﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;

namespace Wipefest.Api.Repositories
{
    public class SequenceService
    {
        private readonly IMongoCollection<Sequence> _sequences;

        public SequenceService(IMongoDatabase database)
        {
            _sequences = database.GetCollection<Sequence>("sequences");
        }

        public async Task<Sequence> Create(string sequenceId, int startingValue)
        {
            var sequence = new Sequence(sequenceId, startingValue);

            await _sequences.InsertOneAsync(sequence);

            return sequence;
        }

        public async Task<int> GetNextValue(string sequenceId)
        {
            var sequence =
                await _sequences.FindOneAndUpdateAsync(
                    s => s.Id == sequenceId,
                    Builders<Sequence>.Update.Inc(s => s.Value, 1));

            if (sequence != null) return sequence.Value + 1;

            await _sequences.InsertOneAsync(new Sequence(sequenceId, 1));

            return 1;
        }
    }

    public class Sequence
    {
        public string Id { get; }
        public int Value { get; }

        public Sequence(string id, int value)
        {
            Id = id;
            Value = value;
        }
    }
}
