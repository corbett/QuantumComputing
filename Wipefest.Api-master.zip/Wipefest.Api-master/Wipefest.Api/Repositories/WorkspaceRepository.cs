﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using MongoDB.Bson;
using MongoDB.Driver;
using Wipefest.Api.Models;

namespace Wipefest.Api.Repositories
{
    public class WorkspaceRepository
    {
        private readonly SequenceService _sequences;
        private readonly IMongoCollection<Workspace> _workspaces;
        private readonly Random _random;

        public WorkspaceRepository(IMongoDatabase database, SequenceService sequences)
        {
            _sequences = sequences;
            _workspaces = database.GetCollection<Workspace>("workspaces");
            _random = new Random(Guid.NewGuid().GetHashCode());
        }

        public async Task<Workspace> Create(WorkspaceDto workspaceDto)
        {
            Workspace workspace = null;
            var success = false;
            var attempt = 0;

            while (!success)
            {
                attempt++;
                workspace = Workspace.FromDto(GenerateId(), 0, workspaceDto);
                try
                {
                    await _workspaces.InsertOneAsync(workspace);
                    success = true;
                }
                catch (MongoDuplicateKeyException)
                {
                    if (attempt >= 4)
                        throw;
                }
            }

            await _sequences.Create(GenerateSequenceId(workspace.Key.Id), 0);
            
            return workspace;
        }

        public async Task<Workspace> Create(Workspace workspace)
        {
            await _workspaces.InsertOneAsync(workspace);
            await _sequences.Create(GenerateSequenceId(workspace.Key.Id), 0);

            return workspace;
        }

        public async Task<Workspace> Update(string id, WorkspaceDto workspaceDto)
        {
            var revision = await _sequences.GetNextValue(GenerateSequenceId(id));
            var workspace = Workspace.FromDto(id, revision, workspaceDto);

            await _workspaces.InsertOneAsync(workspace);

            return workspace;
        }

        public async Task<Maybe<Workspace>> Get(string id, int revision = 0)
        {
            try
            {
                var workspace = await _workspaces.Find(x => x.Key.Id == id && x.Key.Revision == revision).FirstAsync();

                return workspace;
            }
            catch (InvalidOperationException ex) when (ex.Message.Contains("Sequence contains no elements"))
            {
                return Maybe<Workspace>.None;
            }
        }

        public async Task<Maybe<Workspace>> GetLatestApproved(string id)
        {
            var approvedWorkspaces = await _workspaces
                .Find(x => x.Key.Id == id && x.Approved == true) // Have to use == for Mongo to translate the linq properly
                .Sort(Builders<Workspace>.Sort.Descending(x => x.Key.Revision))
                .Limit(1)
                .ToListAsync();

            return approvedWorkspaces.Count == 0
                ? Maybe<Workspace>.None
                : approvedWorkspaces.First();
        }

        public async Task<Maybe<Workspace>> GetLatest(string id)
        {
            var workspaces = await _workspaces
                .Find(x => x.Key.Id == id)
                .Sort(Builders<Workspace>.Sort.Descending(x => x.Key.Revision))
                .Limit(1)
                .ToListAsync();

            return workspaces.Count == 0
                ? Maybe<Workspace>.None
                : workspaces.First();
        }

        public async Task<Result<Workspace>> Copy(string sourceId, int sourceRevision, string destinationId)
        {
            Workspace sourceWorkspace;
            try
            {
                sourceWorkspace = await _workspaces.Find(x => x.Key.Id == sourceId && x.Key.Revision == sourceRevision).FirstAsync();
            }
            catch (InvalidOperationException ex) when (ex.Message.Contains("Sequence contains no elements"))
            {
                return Result.Fail<Workspace>($"Workspace with id {sourceId} and revision {sourceRevision} does not exist");
            }

            var newWorkspace = sourceWorkspace.Rename(destinationId);

            try
            {
                await Create(newWorkspace);
            }
            catch (MongoDuplicateKeyException)
            {
                return Result.Fail<Workspace>($"Workspace with id {destinationId} already exists");
            }

            return Result.Ok(newWorkspace);
        }

        public async Task Approve(string id, int revision)
        {
            await _workspaces
                .UpdateOneAsync(
                    x => x.Key.Id == id && x.Key.Revision == revision,
                    Builders<Workspace>.Update.Set(x => x.Approved, true));
        }

        public async Task Unapprove(string id, int revision)
        {
            await _workspaces
                .UpdateOneAsync(
                    x => x.Key.Id == id && x.Key.Revision == revision,
                    Builders<Workspace>.Update.Set(x => x.Approved, false));
        }

        private string GenerateId()
        {
            const string validCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

            var idCharacters = Enumerable.Range(0, 8).Select(i => validCharacters[_random.Next(validCharacters.Length)]);

            return new string(idCharacters.ToArray());
        }

        private static string GenerateSequenceId(string workspaceCode) => "workspace_" + workspaceCode;
    }
}
