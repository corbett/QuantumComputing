﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Schema;
using CSharpFunctionalExtensions;
using MongoDB.Driver;
using Wipefest.Api.Models;

namespace Wipefest.Api.Repositories
{
    public class StatisticRepository
    {
        private readonly IMongoCollection<Statistic> _statistics;
        private readonly IMongoCollection<Bucket> _buckets;

        public StatisticRepository(IMongoDatabase database)
        {
            _buckets = database.GetCollection<Bucket>("buckets");
            _statistics = database.GetCollection<Statistic>("statistics");
        }

        public async Task Set(ICollection<Statistic> statistics, string reportId, int fightId)
        {
            await DeleteForFight(reportId, fightId);

            if (statistics.Any())
                await Insert(statistics);
        }

        public async Task Insert(IEnumerable<Statistic> statistics)
        {
            await _statistics.InsertManyAsync(statistics);
        }

        public async Task DeleteForFight(string reportId, int fightId)
        {
            await _statistics.DeleteManyAsync(x => x.ReportId == reportId && x.FightId == fightId);
        }

        public async Task<List<BucketCriteria>> GetBucketCriterias()
        {
            var bucketCriterias = await _statistics
                .Aggregate()
                .Group(s => new
                {
                    s.InsightId,
                    s.InsightGroup,
                    s.Name,
                    s.Boss,
                    s.Difficulty
                }, g => new
                {
                    Id = g.Key,
                    Total = g.Count(),
                    g.First().HigherIsBetter
                })
                .Match(x => x.Total >= 20)
                .Project(x => new BucketCriteria
                {
                    InsightId = x.Id.InsightId,
                    InsightGroup = x.Id.InsightGroup,
                    Name = x.Id.Name,
                    Boss = x.Id.Boss,
                    Difficulty = x.Id.Difficulty,
                    HigherIsBetter = x.HigherIsBetter
                })
                .ToListAsync();

            return bucketCriterias;
        }

        public async Task<List<Statistic>> Get(BucketCriteria criteria, DateTime minimumDate, DateTime maximumDate)
        {
            return await _statistics
                .Find(x =>
                    x.InsightId == criteria.InsightId &&
                    x.InsightGroup == criteria.InsightGroup &&
                    x.Name == criteria.Name &&
                    x.Boss == criteria.Boss &&
                    x.Difficulty == criteria.Difficulty &&
                    x.HigherIsBetter == criteria.HigherIsBetter &&
                    x.Timestamp >= minimumDate &&
                    x.Timestamp <= maximumDate)
                .ToListAsync();
        }

        public async Task SetBuckets(IEnumerable<Bucket> buckets, DateTime date)
        {
            buckets = buckets.Select(b =>
            {
                b.Date = date.Date;
                return b;
            });

            await _buckets.DeleteManyAsync(b => b.Date == date.Date);

            await _buckets.InsertManyAsync(buckets);
        }

        public async Task<Maybe<Bucket>> GetBucket(BucketCriteria criteria, DateTime date)
        {
            try
            {
                return await _buckets
                                .Find(x =>
                                    x.Criteria.InsightId == criteria.InsightId &&
                                    x.Criteria.InsightGroup == criteria.InsightGroup &&
                                    x.Criteria.Name == criteria.Name &&
                                    x.Criteria.Boss == criteria.Boss &&
                                    x.Criteria.Difficulty == criteria.Difficulty &&
                                    x.Criteria.HigherIsBetter == criteria.HigherIsBetter &&
                                    x.Date == date.Date)
                                .FirstAsync();
            }
            catch (InvalidOperationException ex) when (ex.Message.Contains("Sequence contains no elements"))
            {
                return Maybe<Bucket>.None;
            }

        }
    }
}
