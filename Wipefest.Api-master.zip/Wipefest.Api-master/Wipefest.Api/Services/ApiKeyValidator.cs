﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;

namespace Wipefest.Api.Services
{
    public class ApiKeyValidator
    {
        private readonly IConfiguration _configuration;

        public ApiKeyValidator(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public bool IsAdmin(string apiKey)
        {
            return apiKey == _configuration["AdminApiKey"];
        }
    }
}
