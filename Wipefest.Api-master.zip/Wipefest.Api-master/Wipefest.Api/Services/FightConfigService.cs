﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using Wipefest.Api.Factories;
using Wipefest.Api.Models;
using Wipefest.Api.Repositories;
using Wipefest.Cli;
using Wipefest.Cli.Fights;

namespace Wipefest.Api.Services
{
    public class FightConfigService
    {
        private readonly WorkspaceRepository _workspaces;
        private readonly FightConfigFactory _fightConfigFactory;

        public FightConfigService(WorkspaceRepository workspaces, FightConfigFactory fightConfigFactory)
        {
            _workspaces = workspaces;
            _fightConfigFactory = fightConfigFactory;
        }

        public async Task<Result<FightConfig>> Get(string group, bool convertToOldGroupNames = false)
        {
            var maybeWorkspace = await _workspaces.GetLatestApproved(group);

            if (maybeWorkspace.HasNoValue)
                return Result.Fail<FightConfig>($"No workspace could be found for group '{group}'");

            var workspace = maybeWorkspace.Value;

            var fightConfigDtoResult = FightConfigDto.FromWorkspace(workspace);

            if (fightConfigDtoResult.IsFailure)
                return Result.Fail<FightConfig>(fightConfigDtoResult.Error);

            var fightConfigResult = await _fightConfigFactory.Create(fightConfigDtoResult.Value, convertToOldGroupNames);

            return fightConfigResult;
        }
    }
}
