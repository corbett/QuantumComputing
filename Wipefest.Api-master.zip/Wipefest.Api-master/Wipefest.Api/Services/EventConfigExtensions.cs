﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using Wipefest.Cli.EventConfigs;

namespace Wipefest.Api.Services
{
    public static class EventConfigExtensions
    {
        public static ICollection<EventConfig> WithOldGroupNames(this IEnumerable<EventConfig> eventConfigs)
        {
            return eventConfigs.Select(config =>
            {
                config.Group = config.Group.ConvertToOldGroupName();
                return config;
            }).ToList();
        }

        public static Result<List<EventConfig>> WithUniqueIds(this IEnumerable<EventConfig> eventConfigs)
        {
            var i = 0;
            var eventConfigsWithUniqueIds = new List<EventConfig>();
            foreach (var config in eventConfigs)
            {
                if (string.IsNullOrWhiteSpace(config.Id))
                {
                    Result<string> uniqueIdResult;
                    (uniqueIdResult, i) = GetUniqueId(eventConfigsWithUniqueIds.Select(x => x.Id).ToList(), i);
                    if (uniqueIdResult.IsFailure)
                    {
                        var eventConfigsWithDuplicateIds =
                            eventConfigsWithUniqueIds
                                .Where(x => eventConfigsWithUniqueIds.Count(y => y.Id == x.Id) > 1)
                                .ToList();

                        return Result.Fail<List<EventConfig>>(
                            $"Cannot have duplicate ids within the same group. {string.Join(". ", eventConfigsWithDuplicateIds.Select(x => $"{x.Id} is a duplicate within group {x.Group}"))}.");
                    }

                    config.Id = uniqueIdResult.Value;
                }

                eventConfigsWithUniqueIds.Add(config);
            }

            return Result.Ok(eventConfigsWithUniqueIds);
        }

        private static (Result<string> id, int i) GetUniqueId(IReadOnlyCollection<string> existingIds, int i)
        {
            const string validIdCharacters = "ZYXWVUTSRQPONMLKJIHGFEDCBA9876543210";
            string id;
            do
            {
                if (i > validIdCharacters.Length * validIdCharacters.Length)
                    return (Result.Fail<string>("Could not generate a unique id"), i);
                
                var firstCharacter = validIdCharacters[(int) Math.Floor((decimal) i / validIdCharacters.Length) % validIdCharacters.Length];
                var secondCharacter = validIdCharacters[i % validIdCharacters.Length];
                id = $"{firstCharacter}{secondCharacter}";
                i++;
            } while (existingIds.Any(existingId => id == existingId));

            return (Result.Ok(id), i);
        }
    }
}
