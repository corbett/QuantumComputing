﻿namespace Wipefest.Api.Services
{
    public class CachedResult<T>
    {
        public int Status { get; set; }
        public string Error { get; set; }
        public T Value { get; set; }
    }
}