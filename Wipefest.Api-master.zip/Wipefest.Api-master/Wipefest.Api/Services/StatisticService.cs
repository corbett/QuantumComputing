﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hangfire;
using MongoDB.Bson;
using Serilog;
using Wipefest.Api.Models;
using Wipefest.Api.Repositories;
using Wipefest.Cli.Fights;
using Wipefest.Cli.Insights;

namespace Wipefest.Api.Services
{
    public class StatisticService
    {
        private static readonly DateTime Epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        private readonly StatisticRepository _statistics;

        public StatisticService(StatisticRepository statistics)
        {
            _statistics = statistics;
        }

        public async Task<List<Statistic>> Set(Fight fight, ICollection<InsightConfig> insightConfigs)
        {
            var statistics = fight.Insights
                .Where(i => i.Interval.Unit == InsightIntervalUnit.EntireFight &&
                            i.Interval.StartUnit == 0 &&
                            i.Interval.EndUnit == 1 &&
                            i.Statistics != null &&
                            i.Statistics.Any())
                .SelectMany(i =>
                {
                    var insightConfig = insightConfigs.FirstOrDefault(c => c.Id == i.Id && c.Group == i.Group);
                    if (insightConfig?.Statistics == null || !insightConfig.Statistics.Any())
                        return new List<Statistic>();

                    return i.Statistics.Select(s =>
                    {
                        var statisticConfig = insightConfig.Statistics.FirstOrDefault(c => c.Name == s.Name);
                        if (statisticConfig == null)
                            return null;

                        return new Statistic
                        {
                            Id = ObjectId.GenerateNewId().ToString(),
                            Timestamp = Epoch.AddMilliseconds(fight.Report.Start + fight.Info.StartTime),
                            ReportId = fight.Report.Id,
                            FightId = fight.Info.Id,
                            InsightId = i.Id,
                            InsightGroup = i.Group,
                            Boss = fight.Info.Boss,
                            Name = s.Name,
                            Value = s.Value,
                            HigherIsBetter = statisticConfig.HigherIsBetter,
                            RaidSize = fight.Raid.Players.Count,
                            RaidItemLevel = fight.Raid.ItemLevel,
                            Difficulty = (Difficulty)fight.Info.Difficulty,
                            Duration = fight.Info.EndTime - fight.Info.StartTime
                        };
                    })
                    .Where(s => s != null);
                })
                .Where(s => s != null)
                .ToList();

            await _statistics.Set(statistics, fight.Report.Id, fight.Info.Id);

            return statistics;
        }

        public async Task<List<Bucket>> CalculateAndStoreBuckets(DateTime date)
        {
            var bucketCriterias = await _statistics.GetBucketCriterias();

            var buckets = new List<Bucket>();
            foreach (var criteria in bucketCriterias)
            {
                var recentStatistics = await _statistics.Get(criteria, date.AddDays(-7), date);

                if (!recentStatistics.Any())
                    continue;

                var higherIsBetter = recentStatistics.First().HigherIsBetter;

                var orderedStatistics = higherIsBetter
                    ? recentStatistics.OrderBy(x => x.Value).ToList()
                    : recentStatistics.OrderByDescending(x => x.Value).ToList();

                var percentiles = new List<BucketPercentile>();
                var step = orderedStatistics.Count / 100.0;
                for (var percentile = 0; percentile <= 100; percentile++)
                {
                    var bottomValue = percentile == 0
                        ? higherIsBetter
                            ? 0
                            : decimal.MaxValue
                        : percentiles[percentile - 1].TopValue;

                    var index = (int)Math.Min(Math.Floor(step * percentile), orderedStatistics.Count - 1);
                    var topValue = orderedStatistics[Math.Min(index + 1, orderedStatistics.Count - 1)].Value;

                    percentiles.Add(new BucketPercentile
                    {
                        Percentile = percentile,
                        BottomValue = bottomValue,
                        TopValue = topValue
                    });
                }

                buckets.Add(new Bucket
                {
                    Date = date,
                    Criteria = criteria,
                    Percentiles = percentiles
                });
            }

            await _statistics.SetBuckets(buckets, date);

            return buckets;
        }

        public async Task<Fight> AttachPercentiles(Fight fight)
        {
            var insights = fight.Insights
                .Where(i => i.Interval.Unit == InsightIntervalUnit.EntireFight &&
                            i.Interval.StartUnit == 0 &&
                            i.Interval.EndUnit == 1 &&
                            i.Statistics != null &&
                            i.Statistics.Any())
                .ToList();

            foreach (var insight in insights)
            {
                var insightConfig =
                    fight.InsightConfigs?.FirstOrDefault(c => c.Id == insight.Id && c.Group == insight.Group);
                if (insightConfig == null)
                    continue;

                foreach (var statistic in insight.Statistics)
                {
                    var statisticConfig = insightConfig.Statistics?.FirstOrDefault(c => c.Name == statistic.Name);
                    if (statisticConfig == null)
                        continue;

                    var maybeBucket = await _statistics.GetBucket(new BucketCriteria
                    {
                        InsightId = insight.Id,
                        InsightGroup = insight.Group.ConvertToNewGroupName(),
                        Name = statistic.Name,
                        Boss = fight.Info.Boss,
                        Difficulty = (Difficulty) fight.Info.Difficulty,
                        HigherIsBetter = statisticConfig.HigherIsBetter
                    }, Epoch.AddMilliseconds(fight.Report.Start + fight.Info.StartTime).Date);

                    if (maybeBucket.HasNoValue)
                        continue;

                    var bucket = maybeBucket.Value;

                    int percentile;
                    if (statisticConfig.HigherIsBetter &&
                        statistic.Value >= bucket.Percentiles.Last().TopValue)
                    {
                        percentile = 100;
                    }
                    else if (!statisticConfig.HigherIsBetter &&
                             statistic.Value <= bucket.Percentiles.Last().TopValue)
                    {
                        percentile = 100;
                    }
                    else
                    {
                        percentile = bucket.Percentiles
                            .FindLastIndex(p =>
                                (p.BottomValue <= statistic.Value && p.TopValue > statistic.Value) || // HigherIsBetter
                                (p.BottomValue >= statistic.Value && p.TopValue < statistic.Value)); // LowerIsBetter
                    }

                    statistic.Percentile = percentile;
                }
            }

            return fight;
        }
    }
}
