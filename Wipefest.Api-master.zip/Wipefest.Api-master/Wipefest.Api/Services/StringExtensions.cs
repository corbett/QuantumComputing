﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MoreLinq;

namespace Wipefest.Api.Services
{
    public static class StringExtensions
    {
        private static Dictionary<string, string> GroupNameToOldGroupName => new Dictionary<string, string>
        {
            { "raid", "R" },
            { "focus", "F" },
            { "tank", "T" },
            { "healer", "H" },
            { "ranged", "RA" },
            { "melee", "M" },

            { "mage", "MAGE" },
            { "paladin", "PALA" },
            { "warrior", "WARR" },
            { "druid", "DRUI" },
            { "death-knight", "DEAT" },
            { "hunter", "HUNT" },
            { "priest", "PRIE" },
            { "rogue", "ROGU" },
            { "shaman", "SHAM" },
            { "warlock", "WARL" },
            { "monk", "MONK" },
            { "demon-hunter", "DEMO" },

            { "mage-arcane", "MAAR" },
            { "mage-fire", "MAFI" },
            { "mage-frost", "MAFR" },
            { "paladin-holy", "PAHO" },
            { "paladin-protection", "PAPR" },
            { "paladin-retribution", "PARE" },
            { "warrior-arms", "WAAR" },
            { "warrior-fury", "WAFU" },
            { "warrior-protection", "WAPR" },
            { "druid-balance", "DRBA" },
            { "druid-feral", "DRFE" },
            { "druid-guardian", "DRGU" },
            { "druid-restoration", "DRRE" },
            { "death-knight-blood", "DEBL" },
            { "death-knight-frost", "DEFR" },
            { "death-knight-unholy", "DEUN" },
            { "hunter-beast-mastery", "HUBE" },
            { "hunter-marksmanship", "HUMA" },
            { "hunter-survival", "HUSU" },
            { "priest-discipline", "PRDI" },
            { "priest-holy", "PRHO" },
            { "priest-shadow", "PRSH" },
            { "rogue-assassination", "ROAS" },
            { "rogue-combat", "ROCO" },
            { "rogue-subtlety", "ROSU" },
            { "shaman-elemental", "SHEL" },
            { "shaman-enhancement", "SHEN" },
            { "shaman-restoration", "SHRE" },
            { "warlock-affliction", "WAAF" },
            { "warlock-demonology", "WADE" },
            { "warlock-destruction", "WADE" },
            { "monk-brewmaster", "MOBR" },
            { "monk-windwalker", "MOWI" },
            { "monk-mistweaver", "MOMI" },
            { "demon-hunter-havoc", "DEHA" },
            { "demon-hunter-vengeance", "DEVE" }
        };

        public static string ConvertToOldGroupName(this string group)
        {
            if (!GroupNameToOldGroupName.ContainsKey(group))
                return group;

            return GroupNameToOldGroupName[group];
        }

        public static string ConvertToNewGroupName(this string group)
        {
            if (!GroupNameToOldGroupName.ContainsValue(group))
                return group;

            return GroupNameToOldGroupName.First(x => x.Value == group).Key;
        }

        public static List<(string Group, List<string> Ids)> ExtractRequire(this string requireString)
        {
            return requireString.Split(',').Select(groupString =>
            {
                var parts = groupString.Split(':');
                var group = parts[0];
                var ids = parts[1].Split(2).ToList();

                return (group, ids);
            }).ToList();
        }

        public static IEnumerable<string> Split(this string str, int chunkSize)
        {
            return Enumerable.Range(0, str.Length / chunkSize)
                .Select(i => str.Substring(i * chunkSize, chunkSize));
        }
    }
}
