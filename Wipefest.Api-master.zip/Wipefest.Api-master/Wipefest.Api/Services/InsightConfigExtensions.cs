﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.Insights;

namespace Wipefest.Api.Services
{
    public static class InsightConfigExtensions
    {
        public static ICollection<InsightConfig> WithOldGroupNames(this IEnumerable<InsightConfig> insightConfigs)
        {
            return insightConfigs.Select(config =>
            {
                var require = config.Require.ExtractRequire();
                foreach (var group in require.Select(x => x.Group))
                {
                    config.Require = config.Require.Replace(group + ":", group.ConvertToOldGroupName() + ":");
                }
                return config;
            }).ToList();
        }
    }
}
