﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Wipefest.Api.Factories;
using Wipefest.Api.Models;
using Wipefest.Api.Repositories;
using Wipefest.Cli;
using Wipefest.Cli.Fights;

namespace Wipefest.Api.Services
{
    public class FightService
    {
        private readonly WorkspaceRepository _workspaces;
        private readonly WipefestCli _wipefest;
        private readonly FightConfigFactory _fightConfigFactory;
        private readonly StatisticService _statisticService;

        public FightService(WorkspaceRepository workspaces, WipefestCli wipefest, FightConfigFactory fightConfigFactory, StatisticService statisticService)
        {
            _workspaces = workspaces;
            _wipefest = wipefest;
            _fightConfigFactory = fightConfigFactory;
            _statisticService = statisticService;
        }

        public async Task<WipefestCliResult<Fight>> Get(
            string reportId,
            int fightId,
            string group,
            MarkupParsingFormat markupFormat = MarkupParsingFormat.Markup,
            ICollection<string> includes = null)
        {
            includes =
                (includes ?? new List<string>())
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .ToList();

            WipefestCliResult<Fight> result;
            
            var maybeWorkspace = await _workspaces.GetLatestApproved(group);

            if (maybeWorkspace.HasNoValue)
            {
                result = await _wipefest.GetFight(reportId, fightId, markupFormat, includes);

                return result;
            }

            var workspace = maybeWorkspace.Value;

            var fightConfigDtoResult = FightConfigDto.FromWorkspace(workspace);

            if (fightConfigDtoResult.IsFailure)
                return WipefestCliResult<Fight>.Fail(400, fightConfigDtoResult.Error);

            var fightConfigDto = fightConfigDtoResult.Value.AppendOldFormatIncludes(includes);

            var fightConfigResult = await _fightConfigFactory.Create(fightConfigDto, true);

            if (fightConfigResult.IsFailure)
                return WipefestCliResult<Fight>.Fail(400, fightConfigResult.Error);

            result = await _wipefest.GetFight(reportId, fightId, markupFormat, null, fightConfigResult.Value);

            if (result.IsSuccess)
                result = WipefestCliResult<Fight>.Ok(
                    await _statisticService.AttachPercentiles(result.Value)
                );

            return result;
        }

        public async Task<WipefestCliResult<Fight>> GetForFightConfig(
            string reportId,
            int fightId,
            FightConfigDto fightConfigDto,
            MarkupParsingFormat markupFormat = MarkupParsingFormat.Markup)
        {
            var fightConfigResult = await _fightConfigFactory.Create(fightConfigDto);
            if (fightConfigResult.IsFailure)
            {
                return WipefestCliResult<Fight>.Fail(400, fightConfigResult.Error);
            }

            var fightConfig = fightConfigResult.Value;

            var result = await _wipefest.GetFight(reportId, fightId, markupFormat, null, fightConfig);

            return result;
        }

        public async Task<WipefestCliResult<Fight>> GetForFightConfig(
            string reportId,
            int fightId,
            FightConfig fightConfig,
            MarkupParsingFormat markupFormat = MarkupParsingFormat.Markup)
        {
            return await _wipefest.GetFight(reportId, fightId, markupFormat, null, fightConfig);
        }
    }
}
