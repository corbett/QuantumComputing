﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Distributed;
using Newtonsoft.Json;
using Wipefest.Cli;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.Fights;
using Wipefest.Cli.Raid;

namespace Wipefest.Api.Services
{
    public class CacheableWipefestCliApi : WipefestCliApi
    {
        private readonly IDistributedCache _cache;

        public CacheableWipefestCliApi(string warcraftLogsApiKey, string[] baseUrls, IDistributedCache cache) : base(warcraftLogsApiKey, baseUrls)
        {
            _cache = cache;
        }

        public override async Task<WipefestCliResult<Fight>> GetFight(
            string reportId,
            int fightId,
            MarkupParsingFormat markupFormat = MarkupParsingFormat.Markup,
            ICollection<string> includes = null,
            FightConfig fightConfig = null)
        {
            var cacheId =
                $"reportId: {reportId}, fightId: {fightId}, markupFormat: {markupFormat}";
            if (includes != null && includes.Any())
            {
                cacheId += $", includes: {string.Join(",", includes.OrderBy(x => x))}";
            }
            if (fightConfig != null)
            {
                cacheId += $", fightConfig: {JsonConvert.SerializeObject(fightConfig).GetHashCode()}";
            }

            var cachedResult = await _cache.GetStringAsync(cacheId);

            if (cachedResult != null)
            {
                var deserializedResult = JsonConvert.DeserializeObject<CachedResult<Fight>>(cachedResult);

                if (!string.IsNullOrWhiteSpace(deserializedResult.Error))
                    return WipefestCliResult<Fight>.Fail(
                        deserializedResult.Status,
                        deserializedResult.Error);

                return WipefestCliResult<Fight>.Ok(deserializedResult.Value);
            }

            var result = await base.GetFight(reportId, fightId, markupFormat, includes, fightConfig);

            if (result.IsSuccess)
            {
                await _cache.SetStringAsync(cacheId, JsonConvert.SerializeObject(result));
            }

            return result;
        }

        public override async Task<WipefestCliResult<Raid>> GetRaid(string reportId, int fightId)
        {
            var cacheId = $"raid, reportId: {reportId}, fightId: {fightId}";

            var cachedResult = await _cache.GetStringAsync(cacheId);

            if (cachedResult != null)
            {
                var deserializedResult = JsonConvert.DeserializeObject<CachedResult<Raid>>(cachedResult);

                if (!string.IsNullOrWhiteSpace(deserializedResult.Error))
                    return WipefestCliResult<Raid>.Fail(
                        deserializedResult.Status,
                        deserializedResult.Error);

                return WipefestCliResult<Raid>.Ok(deserializedResult.Value);
            }

            var result = await base.GetRaid(reportId, fightId);

            await _cache.SetStringAsync(cacheId, JsonConvert.SerializeObject(result));

            return result;
        }
    }
}
