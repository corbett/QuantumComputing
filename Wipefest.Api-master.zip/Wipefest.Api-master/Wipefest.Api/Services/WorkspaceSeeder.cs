﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using CSharpFunctionalExtensions;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Serilog;
using Wipefest.Api.Models;
using Wipefest.Api.Repositories;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.FightEvents;
using Wipefest.Cli.Insights;

namespace Wipefest.Api.Services
{
    public class WorkspaceSeeder
    {
        private readonly WorkspaceRepository _workspaces;
        private readonly HttpClient _httpClient;
        private readonly ILogger _logger;

        public WorkspaceSeeder(WorkspaceRepository workspaces, HttpClient httpClient, ILogger logger)
        {
            _workspaces = workspaces;
            _httpClient = httpClient;
            _logger = logger;
        }

        public async Task<int> Seed()
        {
            const string baseUrl = "https://raw.githubusercontent.com/JoshYaxley/Wipefest.EventConfigs/master/";

            var groupToFileMappings = new Dictionary<string, string>
            {
                {"focus", "general/focus"},
                {"healer", "general/healer"},
                {"melee", "general/melee"},
                {"raid", "general/raid"},
                {"ranged", "general/ranged"},
                {"tank", "general/tank"},
                {"death-knight", "death-knight/death-knight"},
                {"death-knight-frost", "death-knight/frost"},
                {"death-knight-unholy", "death-knight/unholy"},
                {"death-knight-blood", "death-knight/blood"},
                {"demon-hunter", "demon-hunter/demon-hunter"},
                {"demon-hunter-havoc", "demon-hunter/havoc"},
                {"demon-hunter-vengeance", "demon-hunter/vengeance"},
                {"druid", "druid/druid"},
                {"druid-balance", "druid/balance"},
                {"druid-feral", "druid/feral"},
                {"druid-guardian", "druid/guardian"},
                {"druid-restoration", "druid/restoration"},
                {"hunter", "hunter/hunter"},
                {"hunter-beast-mastery", "hunter/beast-mastery"},
                {"hunter-marksmanship", "hunter/marksmanship"},
                {"hunter-survival", "hunter/survival"},
                {"mage", "mage/mage"},
                {"mage-frost", "mage/frost"},
                {"mage-fire", "mage/fire"},
                {"mage-arcane", "mage/arcane"},
                {"monk", "monk/monk"},
                {"monk-windwalker", "monk/windwalker"},
                {"monk-mistweaver", "monk/mistweaver"},
                {"monk-brewmaster", "monk/brewmaster"},
                {"paladin", "paladin/paladin"},
                {"paladin-holy", "paladin/holy"},
                {"paladin-retribution", "paladin/retribution"},
                {"paladin-protection", "paladin/protection"},
                {"priest", "priest/priest"},
                {"priest-holy", "priest/holy"},
                {"priest-shadow", "priest/shadow"},
                {"priest-discipline", "priest/discipline"},
                {"rogue", "rogue/rogue"},
                {"rogue-assassination", "rogue/assassination"},
                {"rogue-combat", "rogue/combat"},
                {"rogue-subtlety", "rogue/subtlety"},
                {"shaman", "shaman/shaman"},
                {"shaman-enhancement", "shaman/enhancement"},
                {"shaman-restoration", "shaman/restoration"},
                {"shaman-elemental", "shaman/elemental"},
                {"warlock", "warlock/warlock"},
                {"warlock-destruction", "warlock/destruction"},
                {"warlock-demonology", "warlock/demonology"},
                {"warlock-affliction", "warlock/affliction"},
                {"warrior", "warrior/warrior"},
                {"warrior-protection", "warrior/protection"},
                {"warrior-fury", "warrior/fury"},
                {"warrior-arms", "warrior/arms"},
                {"2144", ""},
                {"2141", ""},
                {"2128", ""},
                {"2136", ""},
                {"2134", ""},
                {"2145", ""},
                {"2135", ""},
                {"2122", ""}
            };

            var testCases = new List<TestCaseDto>
            {
                new TestCaseDto
                {
                    Name = "Mythic Garothi Worldbreaker",
                    ReportId = "ng2DGa4jwC9q7x8W",
                    FightId = 1
                },
                new TestCaseDto
                {
                    Name = "Heroic Garothi Worldbreaker",
                    ReportId = "4tBPYwHfZrmjFQWv",
                    FightId = 1
                },
                new TestCaseDto
                {
                    Name = "Normal Garothi Worldbreaker",
                    ReportId = "vnawTcV21B7xdt9q",
                    FightId = 1
                }
            };

            var totalCreated = 0;
            var tasks = groupToFileMappings.Select(async pair =>
            {
                var group = pair.Key;
                var file = pair.Value;

                var maybeExistingWorkspace = await _workspaces.Get(group);
                if (maybeExistingWorkspace.HasValue)
                {
                    _logger.Information("{0}: Already exists. Doing nothing.", group);
                    return;
                }

                if (file == "")
                {
                    _logger.Information("{0}: No file specified. Creating as default.", group);
                    await _workspaces.Create(new Workspace(new WorkspaceKey(group, 0), true, testCases));
                    totalCreated++;
                }
                else
                {
                    var url = $"{baseUrl}{file}.json";

                    _logger.Information("{0}: Downloading from {1}.", group, url);

                    var json = await _httpClient.GetStringAsync(url);

                    var eventConfigs = JsonConvert.DeserializeObject<List<EventConfig>>(json);
                    foreach (var eventConfig in eventConfigs)
                    {
                        eventConfig.Friendly = true;
                    }
                    var fightConfig = new FightConfigDto
                    {
                        EventConfigs = eventConfigs,
                        Includes = null,
                        InsightConfigs = null
                    };
                    var fightConfigJson =
                        JsonConvert.SerializeObject(fightConfig, new JsonSerializerSettings
                        {
                            Formatting = Formatting.Indented,
                            NullValueHandling = NullValueHandling.Ignore,
                            ContractResolver = new CamelCasePropertyNamesContractResolver()
                        })
                        .Replace("\r\n", "\n");

                    _logger.Information("{0}: Creating", group);

                    await _workspaces.Create(
                        new Workspace(new WorkspaceKey(group, 0), true, testCases, fightConfigJson));
                    totalCreated++;
                }
            });

            await Task.WhenAll(tasks);

            return totalCreated;
        }
    }
}
