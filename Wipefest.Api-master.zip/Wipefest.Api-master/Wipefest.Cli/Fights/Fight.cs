﻿using System.Collections.Generic;
using System.Linq;
using MoreLinq.Extensions;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.FightEvents;
using Wipefest.Cli.Insights;
using Wipefest.Cli.Reports;

namespace Wipefest.Cli.Fights
{
    public class Fight
    {
        public Report Report { get; set; }
        public FightInfo Info { get; set; }
        public Raid.Raid Raid { get; set; }
        public ICollection<EventConfig> EventConfigs { get; set; }
        public ICollection<InsightConfig> InsightConfigs { get; set; }
        public ICollection<FightEvent> Events { get; set; }
        public ICollection<Insight> Insights { get; set; }

        public ICollection<Ability> Abilities =>
            Events
                .Select(x => x.Ability)
                .Concat(Events
                    .Select(x => x.KillingBlow))
                .Where(x => x != null)
                .DistinctBy(x => x.Guid)
                .ToList();
    }
}
