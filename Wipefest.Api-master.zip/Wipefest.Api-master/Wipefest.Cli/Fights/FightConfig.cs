﻿using System;
using System.Collections.Generic;
using System.Text;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.Insights;

namespace Wipefest.Cli.Fights
{
    public class FightConfig
    {
        public ICollection<EventConfig> EventConfigs { get; set; }
        public ICollection<InsightConfig> InsightConfigs { get; set; }
    }
}
