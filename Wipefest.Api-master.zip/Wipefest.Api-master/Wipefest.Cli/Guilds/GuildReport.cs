﻿namespace Wipefest.Cli.Guilds
{
    public class GuildReport
    {
        public string Id { get; set; }
        public string Owner { get; set; }
        public string Title { get; set; }
        public int Zone { get; set; }
        public long Start { get; set; }
        public long End { get; set; }
    }
}
