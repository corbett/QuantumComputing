# Wipefest CLI C# SDK

This project contains a C# wrapper around the CLI project of the [Wipefest.Core](https://github.com/JoshYaxley/Wipefest.Core) repository, allowing access to the functionality in Wipefest.Core via C#.

## Usage

This library expects the [Wipefest CLI](https://github.com/JoshYaxley/Wipefest.Cli)
to be available,
which can be installed globally using*:

``` bash
npm install -g @wipefest/cli
```

> You can verify that the Wipefest CLI is installed using `wipefest --help`

Create an instance of the CLI client:

``` csharp
var wipefest = new WipefestCli("YOUR_WCL_API_KEY");
```

*Or interact with Wipefest.Core via the API version of the cli ([Docker image here](https://hub.docker.com/r/joshyaxley/wipefest.cli.api/)), which doesn't require having [@wipefest/cli](https://www.npmjs.com/package/@wipefest/cli) installed:

``` csharp
var wipefest = new WipefestCliApi("YOUR_WCL_API_KEY", new[]
    {
        "http://wipefest.cli.api1:3000/",
        "http://wipefest.cli.api2:3000/",
        "http://wipefest.cli.api3:3000/"
    });
```

> Requests to the CLI API will be round-robin load-balanced across the provided base urls (in this example 3 Docker containers have been spun up, with the names of `wipefest.cli.api1` etc).

Retrieve a report:

``` csharp
var result = await wipefest.GetReport("aHMJNvVqGFXKtPzY");

if (result.IsSuccess) {
    var report = result.Value;
}
```

Retrieve and process a fight:

``` csharp
var result = await wipefest.GetFight("aHMJNvVqGFXKtPzY", 15);

if (result.IsSuccess) {
    var fight = result.Value;
}
```

> Replace `YOUR_WCL_API_KEY` with your Warcraft Logs Public Key found
> [here](https://www.warcraftlogs.com/accounts/changeuser).

## Contribute

The best way to contribute is to get in touch on our
[Discord server](https://discord.gg/QhE4hfS).

To download the source code:

``` bash
git clone https://github.com/JoshYaxley/Wipefest.Api.git
cd Wipefest.Api/Wipefest.Cli
dotnet restore
```

Before you can run the tests, you need to make an
`appsettings.json` file in the
`Wipefest.Cli.Tests` folder containing your Warcraft Logs Public Key
(found [here](https://www.warcraftlogs.com/accounts/changeuser)):

``` json
{
    "WarcraftLogsPublicKey": "YOUR_WCL_API_KEY"
}
```

Then you can run the tests:

``` bash
dotnet test Wipefest.Cli.Tests
```

> The tests don't concern themselves too much with the actual data being returned,
> just that data *is* returned and that key fields aren't blank.

This package depends on:

* [Newtonsoft.Json](https://www.nuget.org/packages/Newtonsoft.Json/) for JSON deserialization