﻿namespace Wipefest.Cli
{
    public class WipefestCliResult<T> where T : class
    {
        public bool IsFailure => !string.IsNullOrEmpty(Error);
        public bool IsSuccess => !IsFailure;
        public int Status { get; }
        public string Error { get; }
        public T Value { get; }

        private WipefestCliResult(T value, int status, string error)
        {
            Value = value;
            Status = status;
            Error = error;
        }

        public static WipefestCliResult<T> Ok(T value)
        {
            return new WipefestCliResult<T>(value, 200, null);
        }

        public static WipefestCliResult<T> Fail(int status, string error)
        {
            return new WipefestCliResult<T>(null, status, error);
        }
    }
}
