﻿namespace Wipefest.Cli.Specializations
{
    public class Specialization
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public string ClassName { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
        public bool FocusEnabled { get; set; }
        public string Icon { get; set; }
        public string Include { get; set; }
        public string Group { get; set; }
        public string GeneralInclude { get; set; }
        public string GeneralGroup { get; set; }
    }
}