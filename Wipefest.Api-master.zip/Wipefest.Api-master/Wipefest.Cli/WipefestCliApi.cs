﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;

namespace Wipefest.Cli
{
    public class WipefestCliApi : WipefestCli
    {
        private readonly string[] _baseUrls;
        private int _currentBaseUrlIndex;

        public WipefestCliApi(string warcraftLogsApiKey, string[] baseUrls) : base(warcraftLogsApiKey)
        {
            _baseUrls = baseUrls;
        }

        public override async Task<string> RunCommand(Command command)
        {
            _currentBaseUrlIndex = (_currentBaseUrlIndex + 1) % _baseUrls.Length;

            var httpClient = new HttpClient();

            var json = JsonConvert.SerializeObject(command, new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                ContractResolver = new CamelCasePropertyNamesContractResolver(),
                Converters = new List<JsonConverter>
                {
                    new StringEnumConverter
                    {
                        CamelCaseText = true
                    }
                }
            });
            var content = new StringContent(json, Encoding.UTF8, "application/json");
            var response = await httpClient.PostAsync(_baseUrls[_currentBaseUrlIndex], content);

            return await response.Content.ReadAsStringAsync();
        }
    }
}
