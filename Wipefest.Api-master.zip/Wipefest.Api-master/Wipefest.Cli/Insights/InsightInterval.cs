﻿namespace Wipefest.Cli.Insights
{
    public class InsightInterval
    {
        public long StartTimestamp { get; set; }
        public long EndTimestamp { get; set; }
        public int StartUnit { get; set; }
        public int EndUnit { get; set; }
        public InsightIntervalUnit Unit { get; set; }
    }
}