﻿namespace Wipefest.Cli.Insights
{
    public class InsightStatistic
    {
        public string Name { get; set; }
        public decimal Value { get; set; }
        public int? Percentile { get; set; }
    }
}