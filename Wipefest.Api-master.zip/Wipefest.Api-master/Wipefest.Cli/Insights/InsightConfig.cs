﻿using System;
using System.Collections.Generic;
using System.Text;
using Wipefest.Cli.EventConfigs;

namespace Wipefest.Cli.Insights
{
    public class InsightConfig
    {
        public string Id { get; set; }
        public string Group { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Title { get; set; }
        public string TitleWhenNoEvents { get; set; }
        public string Details { get; set; }
        public string Tip { get; set; }
        public string Custom { get; set; }
        public int? Threshold { get; set; }
        public int? DebuffApplicationTimeRelativeToDamageTime { get; set; }
        public int? GracePeriod { get; set; }
        public string Role { get; set; }
        public string Phase { get; set; }
        public int? Stacks { get; set; }
        public InsightConfigAbility Ability { get; set; }
        public InsightConfigDiscord Discord { get; set; }
        public string Require { get; set; }
        public ICollection<InsightStatisticConfig> Statistics { get; set; }
        public string MainStatistic { get; set; }
    }

    public class InsightConfigAbility
    {
        public int? Id { get; set; }
        public ICollection<int> Ids { get; set; }
    }

    public class InsightConfigDiscord
    {
        public bool? ShowDetails { get; set; }
    }

    public class InsightStatisticConfig
    {
        public string Name { get; set; }
        public bool HigherIsBetter { get; set; }
    }
}
