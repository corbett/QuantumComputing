﻿namespace Wipefest.Cli.Insights
{
    public enum InsightIntervalUnit
    {
        Death,
        Phase,
        Minute,
        EntireFight
    }
}