﻿using System.Collections.Generic;

namespace Wipefest.Cli.Insights
{
    public class Insight
    {
        public string Id { get; set; }
        public string Group { get; set; }
        public InsightInterval Interval { get; set; }
        public string Title { get; set; }
        public string Details { get; set; }
        public string Tip { get; set; }
        public bool Major { get; set; }
        public ICollection<InsightStatistic> Statistics { get; set; }
    }
}