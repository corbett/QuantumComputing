﻿using Wipefest.Cli.Specializations;

namespace Wipefest.Cli.Raid
{
    public class Player
    {
        public string Name { get; set; }
        public string ClassName { get; set; }
        public Specialization Specialization { get; set; }
        public decimal? ItemLevel { get; set; }
        public int ActorId { get; set; }
    }
}