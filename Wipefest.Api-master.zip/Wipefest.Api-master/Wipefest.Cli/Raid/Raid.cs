﻿using System.Collections.Generic;

namespace Wipefest.Cli.Raid
{
    public class Raid
    {
        public ICollection<Player> Players { get; set; }
        public decimal ItemLevel { get; set; }
        public ICollection<Player> Tanks { get; set; }
        public ICollection<Player> Healers { get; set; }
        public ICollection<Player> Ranged { get; set; }
        public ICollection<Player> Melee { get; set; }
    }
}