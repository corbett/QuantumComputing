﻿namespace Wipefest.Cli.Characters
{
    public class ParseForFight
    {
        public long Timestamp { get; set; }
        public string ClassName { get; set; }
        public string Spec { get; set; }
        public decimal Percent { get; set; }
        public decimal ItemLevel { get; set; }
        public string ReportId { get; set; }
        public int FightId { get; set; }
    }
}