﻿using System.Collections.Generic;

namespace Wipefest.Cli.Characters
{
    public class ParsesForEncounter
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public ICollection<ParsesForDifficulty> Difficulties { get; set; }
    }
}