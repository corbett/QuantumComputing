﻿using System.Collections.Generic;

namespace Wipefest.Cli.Characters
{
    public class ParsesForDifficulty
    {
        public int Difficulty { get; set; }
        public ICollection<ParseForFight> Fights { get; set; }
    }
}