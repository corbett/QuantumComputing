﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using Wipefest.Cli.Characters;
using Wipefest.Cli.Encounters;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.Fights;
using Wipefest.Cli.Guilds;
using Wipefest.Cli.Reports;
using Wipefest.Cli.Specializations;

namespace Wipefest.Cli
{
    public class WipefestCli
    {
        private readonly string _warcraftLogsApiKey;

        public WipefestCli(
            string warcraftLogsApiKey)
        {
            _warcraftLogsApiKey = warcraftLogsApiKey;
        }

        public virtual async Task<WipefestCliResult<Report>> GetReport(string reportId)
        {
            return await RunWipefestCommand<Report>(new Command
            {
                ReportId = reportId,
                WarcraftLogsApiKey = _warcraftLogsApiKey
            });
        }

        public virtual async Task<WipefestCliResult<Fight>> GetFight(
            string reportId,
            int fightId,
            MarkupParsingFormat markupFormat = MarkupParsingFormat.Markup,
            ICollection<string> includes = null,
            FightConfig fightConfig = null)
        {
            var command = new Command
            {
                ReportId = reportId,
                FightId = fightId,
                WarcraftLogsApiKey = _warcraftLogsApiKey
            };

            if (markupFormat != MarkupParsingFormat.Markup)
            {
                command.PreParse = markupFormat;
            }
            
            if (includes != null && includes.Any())
            {
                command.Includes = includes;
            }

            if (fightConfig != null)
            {
                command.FightConfig = fightConfig;
            }

            return await RunWipefestCommand<Fight>(command);
        }

        public virtual async Task<WipefestCliResult<Raid.Raid>> GetRaid(string reportId, int fightId)
        {
            return await RunWipefestCommand<Raid.Raid>(new Command
            {
                Raid = true,
                ReportId = reportId,
                FightId = fightId,
                WarcraftLogsApiKey = _warcraftLogsApiKey
            });
        }

        public virtual async Task<WipefestCliResult<List<Encounter>>> GetEncounters()
        {
            return await RunWipefestCommand<List<Encounter>>(new Command
            {
                Encounters = true
            });
        }

        public virtual async Task<WipefestCliResult<List<Specialization>>> GetSpecializations()
        {
            return await RunWipefestCommand<List<Specialization>>(new Command
            {
                Specializations = true
            });
        }

        public virtual async Task<WipefestCliResult<GuildReport[]>> GetGuildReports(
            string region,
            string realm,
            string name)
        {
            return await RunWipefestCommand<GuildReport[]>(new Command
            {
                Region = region,
                Realm = realm,
                Guild = name,
                WarcraftLogsApiKey = _warcraftLogsApiKey
            });
        }

        public virtual async Task<WipefestCliResult<ParsesForEncounter[]>> GetCharacterParses(
            string region,
            string realm,
            string name,
            int zone,
            ICollection<int> partitions)
        {
            return await RunWipefestCommand<ParsesForEncounter[]>(new Command
            {
                Region = region,
                Realm = realm,
                Character = name,
                Zone = zone,
                Partitions = partitions,
                WarcraftLogsApiKey = _warcraftLogsApiKey
            });
        }

        public virtual async Task<WipefestCliResult<string>> ParseMarkup(string markup, MarkupParsingFormat format = MarkupParsingFormat.Text)
        {
            if (format == MarkupParsingFormat.Markup)
                return WipefestCliResult<string>.Ok(markup);

            return await RunWipefestCommand(new Command
            {
                ParseMarkup = markup,
                Output = format
            });
        }

        private async Task<WipefestCliResult<T>> RunWipefestCommand<T>(Command command) where T : class
        {
            var stringResult = await RunWipefestCommand(command);

            if (stringResult.IsFailure)
                return WipefestCliResult<T>.Fail(stringResult.Status, stringResult.Error);

            var value = JsonConvert.DeserializeObject<T>(stringResult.Value);

            return WipefestCliResult<T>.Ok(value);
        }

        private async Task<WipefestCliResult<string>> RunWipefestCommand(Command command)
        {
            var json = await RunCommand(command);
            try
            {
                dynamic result = JsonConvert.DeserializeObject(json);

                if (!string.IsNullOrWhiteSpace((string)result.error))
                    return WipefestCliResult<string>.Fail((int)result.status, (string)result.error);

                return WipefestCliResult<string>.Ok(result.value.ToString());
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to run wipefest command \"{command}\" (result was \"{json}\")", ex);
            }
        }

        public virtual async Task<string> RunCommand(Command command)
        {
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = IsWindows() ? "cmd" : "/bin/bash",
                    Arguments = (IsWindows() ? "/S /C " : "-c ") + $"\"wipefest {command}\"",
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                }
            };
            process.Start();
            var output = (await process.StandardOutput.ReadToEndAsync()).Trim();
            process.WaitForExit();

            return output;
        }

        private static bool IsWindows()
        {
            return RuntimeInformation.IsOSPlatform(OSPlatform.Windows);
        }
    }
}

