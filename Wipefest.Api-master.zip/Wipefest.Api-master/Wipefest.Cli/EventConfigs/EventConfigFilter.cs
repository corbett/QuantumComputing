﻿using System.Collections.Generic;

namespace Wipefest.Cli.EventConfigs
{
    public class EventConfigFilter
    {
        public string Type { get; set; }
        public ICollection<string> Types { get; set; }
        public EventConfigFilterAbility Ability { get; set; }
        public EventConfigFilterActor Actor { get; set; }
        public bool? First { get; set; }
        public bool? FirstPerInstance { get; set; }
        public int? Index { get; set; }
        public int? Minimum { get; set; }
        public int? Range { get; set; }
        public int? RangePerActor { get; set; }
        public int? Stack { get; set; }
        public string Query { get; set; }
    }
}