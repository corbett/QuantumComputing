﻿using System.Collections.Generic;

namespace Wipefest.Cli.EventConfigs
{
    public class EventConfigFilterAbility
    {
        public int? Id { get; set; }
        public ICollection<int> Ids { get; set; }
    }
}