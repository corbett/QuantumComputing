﻿using System.Collections.Generic;

namespace Wipefest.Cli.EventConfigs
{
    public class EventConfig
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public ICollection<string> Tags { get; set; }
        public bool Show { get; set; }
        public string EventType { get; set; }
        public bool Friendly { get; set; }
        public EventConfigFilter Filter { get; set; }
        public ICollection<int> Difficulties { get; set; }
        public string Target { get; set; }
        public bool? ShowTarget { get; set; }
        public bool? IncludePetTargets { get; set; }
        public string Source { get; set; }
        public bool? ShowSource { get; set; }
        public string Title { get; set; }
        public long? Timestamp { get; set; }
        public ICollection<long> Timestamps { get; set; }
        public ICollection<string> Titles { get; set; }
        public bool? Collapsed { get; set; }
        public string Icon { get; set; }
        public string Style { get; set; }
        public string File { get; set; }
        public string Group { get; set; }
        public bool? ShowByDefault { get; set; }
        public bool? CollapsedByDefault { get; set; }
    }
}