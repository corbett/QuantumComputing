﻿namespace Wipefest.Cli.EventConfigs
{
    public class EventConfigFilterActor
    {
        public int? Id { get; set; }
        public string Name { get; set; }
        public int? Percent { get; set; }
    }
}