﻿namespace Wipefest.Cli.Encounters
{
    public class Encounter
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
