﻿using System.Collections.Generic;

namespace Wipefest.Cli.Reports
{
    public class Actor
    {
        public ICollection<FightId> Fights { get; set; }
        public int Id { get; set; }
        public int Guid { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public int Instance { get; set; }
    }
}