﻿namespace Wipefest.Cli.Reports
{
    public class FightId
    {
        public int Id { get; set; }
    }
}