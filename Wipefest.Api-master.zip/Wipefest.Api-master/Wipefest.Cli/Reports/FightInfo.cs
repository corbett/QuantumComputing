﻿using Newtonsoft.Json;

namespace Wipefest.Cli.Reports
{
    public class FightInfo
    {
        public int Boss { get; set; }
        public int BossPercentage { get; set; }
        public int Difficulty { get; set; }
        [JsonProperty("end_time")]
        public long EndTime { get; set; }
        public int FightPercentage { get; set; }
        public int Id { get; set; }
        public bool Kill { get; set; }
        public int LastPhaseForPercentageDisplay { get; set; }
        public string Name { get; set; }
        public int Partial { get; set; }
        public int Size { get; set; }
        [JsonProperty("start_time")]
        public long StartTime { get; set; }
    }
}