﻿namespace Wipefest.Cli.Reports
{
    public class PetActor : Actor
    {
        public int PetOwner { get; set; }
    }
}