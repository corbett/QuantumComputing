﻿using System.Collections.Generic;

namespace Wipefest.Cli.Reports
{
    public class Report
    {
        public string Id { get; set; }
        public ICollection<Actor> Friendlies { get; set; }
        public ICollection<PetActor> FriendlyPets { get; set; }
        public ICollection<Actor> Enemies { get; set; }
        public ICollection<FightInfo> Fights { get; set; }
        public string Title { get; set; }
        public string Owner { get; set; }
        public long Start { get; set; }
        public long End { get; set; }
    }
}
