﻿namespace Wipefest.Cli
{
    public enum MarkupParsingFormat
    {
        Markup,
        Text,
        Html
    }
}