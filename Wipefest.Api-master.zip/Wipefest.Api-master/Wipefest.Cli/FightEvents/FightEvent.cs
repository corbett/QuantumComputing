﻿using System.Collections.Generic;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.Reports;

namespace Wipefest.Cli.FightEvents
{
    public class FightEvent
    {
        public EventConfig Config { get; set; }
        public long Timestamp { get; set; }
        public string MinutesAndSeconds { get; set; }
        public int? X { get; set; }
        public int? Y { get; set; }
        public int? Sequence { get; set; }
        public bool IsFriendly { get; set; }
        public string Title { get; set; }
        public string TableTitle { get; set; }
        public Ability Ability { get; set; }
        public int? Stack { get; set; }
        public Ability KillingBlow { get; set; }
        public int? Damage { get; set; }
        public int? Absorbed { get; set; }
        public int? Overkill { get; set; }
        public int? DeathWindow { get; set; }
        public int? DamageTaken { get; set; }
        public int? HealingReceived { get; set; }
        public Actor Source { get; set; }
        public Actor Target { get; set; }
        public Actor From { get; set; }
        public Actor Actor { get; set; }
        public int? Instance { get; set; }
        public ICollection<FightEvent> ChildEvents { get; set; }
        public bool IsChild { get; set; }
        public string Details { get; set; }
        public string Phase { get; set; }
        public string Text { get; set; }
        public bool? Subtitle { get; set; }
        public bool? Kill { get; set; }
    }
}