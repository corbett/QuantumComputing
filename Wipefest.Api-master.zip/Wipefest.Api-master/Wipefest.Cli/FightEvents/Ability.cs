﻿namespace Wipefest.Cli.FightEvents
{
    public class Ability
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public int Guid { get; set; }
        public string AbilityIcon { get; set; }
        public string IconUrl { get; set; }
        public string Url { get; set; }
    }
}