﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using Wipefest.Cli.EventConfigs;
using Wipefest.Cli.Fights;

namespace Wipefest.Cli
{
    public class Command
    {
        public string WarcraftLogsApiKey { get; set; }
        public bool? Encounters { get; set; }
        public bool? Specializations { get; set; }
        public bool? Raid { get; set; }
        public string ReportId { get; set; }
        public int? FightId { get; set; }
        public ICollection<string> Includes { get; set; }
        public string EventConfigAccount { get; set; }
        public string EventConfigBranch { get; set; }
        public FightConfig FightConfig { get; set; }
        public MarkupParsingFormat? PreParse { get; set; }
        public string ParseMarkup { get; set; }
        public MarkupParsingFormat? Output { get; set; }
        public string Region { get; set; }
        public string Realm { get; set; }
        public string Guild { get; set; }
        public string Character { get; set; }
        public int? Zone { get; set; }
        public ICollection<int> Partitions { get; set; }

        public override string ToString()
        {
            var arguments = new List<string>();

            if (WarcraftLogsApiKey != null)
            {
                arguments.Add("--wcl-api-key");
                arguments.Add(WarcraftLogsApiKey);
            }

            if (Encounters == true)
            {
                arguments.Add("--encounters");
            }

            if (Specializations == true)
            {
                arguments.Add("--specializations");
            }

            if (Raid == true)
            {
                arguments.Add("--raid");
            }

            if (ReportId != null)
            {
                arguments.Add("--report");
                arguments.Add(ReportId);
            }

            if (FightId != null)
            {
                arguments.Add("--fight");
                arguments.Add(FightId.ToString());
            }

            if (Includes != null)
            {
                arguments.Add("--includes");
                arguments.Add(string.Join(",", Includes));
            }

            if (EventConfigAccount != null)
            {
                arguments.Add("--event-config-account");
                arguments.Add(EventConfigAccount);
            }

            if (EventConfigBranch != null)
            {
                arguments.Add("--event-config-branch");
                arguments.Add(EventConfigBranch);
            }

            if (FightConfig != null)
            {
                arguments.Add("--fight-config");
                arguments.Add("'" + JsonConvert.SerializeObject(FightConfig) + "'");
            }

            if (PreParse != null)
            {
                arguments.Add("--pre-parse");
                arguments.Add(PreParse.ToString().ToLower());
            }

            if (ParseMarkup != null)
            {
                arguments.Add("--parse-markup");
                arguments.Add("\"" + ParseMarkup.Replace("\"", "'") + "\"");
            }

            if (Output != null)
            {
                arguments.Add("--output");
                arguments.Add(Output.ToString().ToLower());
            }

            if (Region != null)
            {
                arguments.Add("--region");
                arguments.Add(Region);
            }

            if (Realm != null)
            {
                arguments.Add("--realm");
                arguments.Add("\"" + Realm + "\"");
            }

            if (Guild != null)
            {
                arguments.Add("--guild");
                arguments.Add("\"" + Guild + "\"");
            }

            if (Character != null)
            {
                arguments.Add("--character");
                arguments.Add(Character);
            }

            if (Zone != null)
            {
                arguments.Add("--zone");
                arguments.Add(Zone.ToString());
            }

            if (Partitions != null)
            {
                arguments.Add("--partitions");
                arguments.Add(string.Join(",", Partitions));
            }

            return string.Join(" ", arguments);
        }
    }
}
