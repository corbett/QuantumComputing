using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Configuration;
using Wipefest.Cli.Fights;
using Xunit;

namespace Wipefest.Cli.Tests
{
    public class WipefestCliTests
    {
        private readonly string _warcraftLogsApiKey;

        public WipefestCliTests()
        {
            var configBuilder = new ConfigurationBuilder();
            if (File.Exists("appsettings.json"))
            {
                configBuilder.AddJsonFile("appsettings.json");
            }
            configBuilder.AddEnvironmentVariables();

            var config = configBuilder.Build();

            _warcraftLogsApiKey = config["WarcraftLogsApiKey"];
        }

        [Fact]
        public async Task Can_get_report()
        {
            var wipefest = new WipefestCli(_warcraftLogsApiKey);
            var result = await wipefest.GetReport("m3LzjAJCrghHB6pW");
            var report = result.Value;

            report.End.Should().BePositive();
            report.Id.Should().NotBeNullOrEmpty();
            report.Owner.Should().NotBeNullOrEmpty();
            report.Start.Should().BePositive();
            report.Title.Should().NotBeNullOrEmpty();

            report.Enemies.Should().NotBeEmpty();
            var enemy = report.Enemies.First();
            enemy.Fights.Should().NotBeEmpty();
            enemy.Guid.Should().BePositive();
            enemy.Name.Should().NotBeNullOrEmpty();
            enemy.Type.Should().NotBeNullOrEmpty();

            report.Fights.Should().NotBeEmpty();
            var fightInfo = report.Fights.First();
            fightInfo.EndTime.Should().BePositive();
            fightInfo.Name.Should().NotBeNullOrEmpty();
            fightInfo.StartTime.Should().BePositive();

            report.Friendlies.Should().NotBeEmpty();
            var friendly = report.Friendlies.First();
            friendly.Fights.Should().NotBeEmpty();
            friendly.Guid.Should().BePositive();
            friendly.Name.Should().NotBeNullOrEmpty();
            friendly.Type.Should().NotBeNullOrEmpty();

            report.FriendlyPets.Should().NotBeEmpty();
            var pet = report.FriendlyPets.First();
            pet.Fights.Should().NotBeEmpty();
            pet.Guid.Should().BePositive();
            pet.Name.Should().NotBeNullOrEmpty();
            pet.Type.Should().NotBeNullOrEmpty();
        }

        [Fact]
        public async Task Can_not_get_report()
        {
            var wipefest = new WipefestCli(_warcraftLogsApiKey);
            var result = await wipefest.GetReport("m3LzjAJCrghHB6p");

            result.Status.Should().Be(400);
            result.Error.Should().NotBeEmpty();
        }

        [Theory]
        [InlineData("79qvaybHdP6MmFj4", 12, null)]
        public async Task Can_get_fight(string reportId, int fightId, ICollection<string> includes)
        {
            var wipefest = new WipefestCli(_warcraftLogsApiKey);
            var result = await wipefest.GetFight(reportId, fightId, MarkupParsingFormat.Text, includes);
            var fight = result.Value;

            CheckKeyFightPropertiesArePopulated(fight);
        }

        [Fact]
        public async Task Can_get_raid()
        {
            var wipefest = new WipefestCli(_warcraftLogsApiKey);
            var result = await wipefest.GetRaid("vLaYkKjMJCZ1WfrQ", 2);
            var raid = result.Value;

            raid.Players.Should().HaveCount(22);
            raid.Tanks.Should().HaveCount(2);
            raid.Healers.Should().HaveCount(3);
            raid.Ranged.Should().HaveCount(10);
            raid.Melee.Should().HaveCount(7);
            raid.ItemLevel.Should().BeGreaterThan(950);
            raid.ItemLevel.Should().BeLessThan(951);
        }

        [Fact]
        public async Task Can_parse_markup()
        {
            var wipefest = new WipefestCli("");

            (await wipefest
                    .ParseMarkup("{[style=\"bold\"] Hello}", MarkupParsingFormat.Html))
                    .Value
                .Should().Be("<span class=\"markup-bold\">Hello</span>");

            (await wipefest
                    .ParseMarkup("{[style=\"bold\"] Hello}"))
                    .Value
                .Should().Be("Hello");
        }

        [Fact]
        public async Task Can_get_encounters()
        {
            var wipefest = new WipefestCli("");

            var result = await wipefest.GetEncounters();
            var encounters = result.Value;

            encounters.Should().NotBeNullOrEmpty();
        }

        [Fact]
        public async Task Can_get_specializations()
        {
            var wipefest = new WipefestCli("");

            var result = await wipefest.GetSpecializations();
            var specializations = result.Value;

            specializations.Should().NotBeNullOrEmpty();
        }

        [Theory]
        [InlineData("EU", "Ravencrest", "Reaction")]
        [InlineData("US", "Moon-Guard", "Dark Intentions")]
        public async Task Can_get_guild_reports(string region, string realm, string name)
        {
            var wipefest = new WipefestCli(_warcraftLogsApiKey);

            var result = await wipefest.GetGuildReports(region, realm, name);
            var reports = result.Value;

            reports.Length.Should().BeGreaterThan(100);
        }

        [Fact]
        public async Task Cannot_get_guild_reports_for_non_existent_guild()
        {
            var wipefest = new WipefestCli(_warcraftLogsApiKey);

            var result = await wipefest.GetGuildReports("EU", "Ravencrest", "dfjsdf893y4rkjshdfksdf");

            result.IsFailure.Should().BeTrue();
            result.Status.Should().Be(400);
        }

        [Fact]
        public async Task Can_get_character_parses()
        {
            var wipefest = new WipefestCli(_warcraftLogsApiKey);

            var result = await wipefest.GetCharacterParses("EU", "Kazzak", "Vanyali", 17, new[] {1});
            var parses = result.Value;

            parses.Length.Should().BeGreaterThan(10);
        }

        [Fact]
        public async Task Cannot_get_character_parses_for_non_existent_character()
        {
            var wipefest = new WipefestCli(_warcraftLogsApiKey);

            var result = await wipefest.GetCharacterParses("EU", "Ravencrest", "dfjsdf893y4rkjshdfksdf", 17, new[] {1});

            result.IsSuccess.Should().BeTrue();
            result.Value.Should().BeEmpty();
        }

        private void CheckKeyFightPropertiesArePopulated(Fight fight)
        {
            var report = fight.Report;
            report.End.Should().BePositive();
            report.Id.Should().NotBeNullOrEmpty();
            report.Owner.Should().NotBeNullOrEmpty();
            report.Start.Should().BePositive();
            report.Title.Should().NotBeNullOrEmpty();

            report.Enemies.Should().NotBeEmpty();
            var enemy = report.Enemies.First();
            enemy.Fights.Should().NotBeEmpty();
            enemy.Guid.Should().BePositive();
            enemy.Name.Should().NotBeNullOrEmpty();
            enemy.Type.Should().NotBeNullOrEmpty();

            report.Fights.Should().NotBeEmpty();
            var fightInfo = report.Fights.First();
            fightInfo.EndTime.Should().BePositive();
            fightInfo.Name.Should().NotBeNullOrEmpty();
            fightInfo.StartTime.Should().BeGreaterOrEqualTo(0);

            report.Friendlies.Should().NotBeEmpty();
            var friendly = report.Friendlies.First();
            friendly.Fights.Should().NotBeEmpty();
            friendly.Guid.Should().BePositive();
            friendly.Name.Should().NotBeNullOrEmpty();
            friendly.Type.Should().NotBeNullOrEmpty();

            report.FriendlyPets.Should().NotBeEmpty();
            var pet = report.FriendlyPets.First();
            pet.Fights.Should().NotBeEmpty();
            pet.Guid.Should().BePositive();
            pet.Name.Should().NotBeNullOrEmpty();
            pet.Type.Should().NotBeNullOrEmpty();

            var info = fight.Info;
            info.EndTime.Should().BePositive();
            info.Name.Should().NotBeNullOrEmpty();
            info.StartTime.Should().BePositive();

            fight.EventConfigs.Should().NotBeEmpty();
            var config = fight.EventConfigs.First();
            config.Id.Should().NotBeNullOrEmpty();
            config.Name.Should().NotBeNullOrEmpty();
            config.Group.Should().NotBeNullOrEmpty();
            config.Tags.Should().NotBeEmpty();
            var tag = config.Tags.First();
            tag.Should().NotBeNullOrEmpty();

            fight.Raid.Should().NotBeNull();
            var raid = fight.Raid;
            raid.Players.Should().NotBeNullOrEmpty();
            var player = raid.Players.First();
            player.Name.Should().NotBeNullOrEmpty();

            fight.Events.Should().NotBeNullOrEmpty();
            var fightEvent = fight.Events.First();
            fightEvent.Title.Should().NotBeNullOrEmpty();
            fightEvent.TableTitle.Should().NotBeNullOrEmpty();

            fight.Insights.Should().NotBeNullOrEmpty();
            var insight = fight.Insights.First();
            insight.Id.Should().NotBeNullOrEmpty();
            insight.Title.Should().NotBeNullOrEmpty();
        }
    }
}
