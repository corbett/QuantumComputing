# Wipefest API

The [Wipefest API](https://api.wipefest.net/) is a public API that sits between the [Wipefest](https://github.com/JoshYaxley/Wipefest) frontend and the [Wipefest.Core](https://github.com/JoshYaxley/Wipefest.Core) library. It provides a layer for data transformation, as well as caching. Down the line, it will also provide persistence of Insights (to drive comparisons), and potentially authentication (via either our own authentication server or other providers).

## Usage

To run the API, ensure [Docker](https://www.docker.com/community-edition) is installed. Then, update the `docker-compose.yml` file to contain your [Warcraft Logs API key](https://www.warcraftlogs.com/accounts/changeuser) (or create a `docker-compose.override.yml` file if you are using Visual Studio's built-in Docker support).

At this point, I would recommend using Visual Studio's built-in Docker support to let you debug the project in Docker.

Alternatively, execute the following command:

```
docker-compose up
```

The API and its dependencies will be ran. Then, navigate to [http://localhost:80/swagger](http://localhost:80/swagger/). You can change the port that it will run on by modifying the `docker-compose.yml` or `docker-compose.override.yml` file.

## Contribute

If you want to contribute, get in touch on our [Discord server](https://discord.gg/QhE4hfS) or via the issue tracker.