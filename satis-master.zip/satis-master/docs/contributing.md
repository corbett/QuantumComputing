---
layout: default
permalink: contributing
title: Contributing
---

## Contributing

Please note that this project is released with a <a href="http://contributor-covenant.org/version/1/4/">Contributor Code of Conduct</a>. By participating in this project you agree to abide by its terms.

Fork the project, create a feature branch, and send us a pull request.
