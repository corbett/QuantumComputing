<?php
// Make a MySQL Connection, chage settings according to your database
$conn = new PDO('mysql:host=localhost;dbname=DATABASE_NAME;charset=utf8', 'USER_NAME', 'PASSWORD');
