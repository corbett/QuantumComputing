<?php
/**
* @file
* A single location to store configuration.
*/
define('CONSUMER_KEY', 'TWITTER CONSUMER KEY');
define('CONSUMER_SECRET', 'TWITTER_CONSUMER_SECRET');
define('OAUTH_CALLBACK', 'TWITTER APP CALLBACK URL');
