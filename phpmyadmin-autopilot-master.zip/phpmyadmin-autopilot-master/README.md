# Autopilot Pattern PhpMyAdmin

*Implementation of PhpMyAdmin in Docker using the Autopilot Pattern*

Intended to be used with the autopilot pattern for [consul](https://github.com/autopilotpattern/consul) and [MySQL](https://github.com/autopilotpattern/mysql).


