//
//  ViewController.h
//  CMPConsentToolDemoApp
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

