# Mobile In-App CMP API v1.0: Transparency & Consent Framework

Status: Not final, based on draft specs, and pending further review by working group and Commit Group