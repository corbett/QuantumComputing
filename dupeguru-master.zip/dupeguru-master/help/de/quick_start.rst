Schnellstart
============

Damit Sie sich schnell mit dupeGuru zurechtfinden, machen wir für den Anfang einen Standardscan mit den Voreinstellungen.

* dupeGuru starten.
* Zu scannende Ordner entweder mit drag & drop oder dem "+" Knopf auswählen.
* Drücken Sie auf **Scan**.
* Warten Sie bis der Scanvorgang fertig ist.
* Betrachten Sie jedes Duplikat (die eingerückten Dateien) und überprüfen ob es wirklich ein Duplikat der Referenzdatei ist (die obere nicht eingerückte Datei ohne Markierungsfeld).
* Wenn eine Datei kein Duplikat ist, wählen Sie es aus und drücken auf **Aktionen-->Entferne Ausgewählte aus den Ergebnissen**.
* Erst wenn Sie sicher sind, das keine Falsch-Duplikate mehr in den Ergebnissen sind, drücken Sie auf **Bearbeiten-->Alle markieren**, und dann **Aktionen-->Verschiebe Markierte in den Mülleimer**.

Das war nur ein einfacher Scan. Es gibt viele Optionen mit denen der Suchdurchlauf beeinflusst werden und einige Methoden zur Begutachtung und Veränderung der Ergebnisliste. Um mehr über sie zu erfahren, lesen Sie die restlichen Hilfedateien.
