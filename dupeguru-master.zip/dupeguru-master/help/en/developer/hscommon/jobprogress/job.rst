hscommon.jobprogress.job
========================

.. automodule:: hscommon.jobprogress.job

    .. autosummary::
        
        Job
        NullJob
    
    .. autoclass:: Job
        :members:
        :private-members:

    .. autoclass:: NullJob
        :members:

