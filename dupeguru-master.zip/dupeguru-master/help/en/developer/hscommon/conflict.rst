hscommon.conflict
=================

.. automodule:: hscommon.conflict
    :members:
