hscommon.desktop
================

.. automodule:: hscommon.desktop
    :members:
