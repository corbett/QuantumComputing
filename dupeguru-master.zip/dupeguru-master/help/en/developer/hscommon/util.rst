hscommon.util
=============

.. automodule:: hscommon.util
    :members:
