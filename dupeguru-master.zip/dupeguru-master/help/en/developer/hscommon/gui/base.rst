hscommon.gui.base
=================

.. automodule:: hscommon.gui.base

    .. autosummary::
        
        GUIObject
    
    .. autoclass:: GUIObject
        :members:
        :private-members:
