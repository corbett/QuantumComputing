core.results
============

.. automodule:: core.results
    :members:
