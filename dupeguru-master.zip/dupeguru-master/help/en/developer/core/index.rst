core
====

.. toctree::
    :maxdepth: 2
    
    app
    fs
    engine
    directories
    results
    gui/index
