Please note that dupeGuru is currently
[unmaintained](https://github.com/hsoft/dupeguru#current-status-unmaintained). That means that this
issue is unlikely to be answered in a timely manner.

