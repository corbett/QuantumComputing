from hscommon.testutil import pytest_funcarg__app # noqa
