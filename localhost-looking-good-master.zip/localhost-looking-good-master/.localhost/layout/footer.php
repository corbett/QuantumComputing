		</div><!-- .container -->

		<script src="<?= home_url( '/.localhost/assets/js/jquery-2.2.4.min.js' ); ?>"></script>
		<script src="<?= home_url( '/.localhost/assets/js/bootstrap.min.js' ); ?>"></script>
		<script src="<?= home_url( '/.localhost/assets/js/themes.js' ); ?>"></script>
	</body>
</html>
