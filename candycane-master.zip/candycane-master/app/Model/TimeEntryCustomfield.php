<?php

class TimeEntryCustomfield extends AppModel
{
    var $useTable = false;
#  def type_name
#    :label_spent_time
#  end
}