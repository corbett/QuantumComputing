<?php
class UserCustomField extends AppModel {
  var $useTable = false;
#  def type_name
#    :label_user_plural
#  end
}