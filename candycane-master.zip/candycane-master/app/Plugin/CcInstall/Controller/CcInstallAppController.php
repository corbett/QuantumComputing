<?php
class CcInstallAppController extends AppController {
	
	public function beforeFilter() {
		return;
	}

}