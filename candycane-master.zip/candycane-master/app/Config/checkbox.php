<?php
$config = array();
$config['tags']['tag'] = '%3$s';
$config['tags']['label'] = '%3$s</label>';
$config['tags']['checkboxmultiple'] = '<label class="floating">'.'<input type="checkbox" name="%s[]"%s />';
return $config;
