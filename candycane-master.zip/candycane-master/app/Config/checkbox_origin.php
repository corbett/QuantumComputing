<?php
$config = array();
$config['tags']['tag'] = '<%s%s>%s</%s>';
$config['tags']['label'] = '<label for="%s"%s>%s</label>';
$config['tags']['checkboxmultiple'] = '<input type="checkbox" name="%s[]"%s />';
return $config;
