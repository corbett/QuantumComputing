<?php 
class WikiContentVersionFixture extends CakeTestFixture {
  var $name = 'WikiContentVersion';
  var $import = array('table'=>'wiki_content_versions');
  var $records = array(
  );
}