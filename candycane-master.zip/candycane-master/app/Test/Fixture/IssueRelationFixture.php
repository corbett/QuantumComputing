<?php 
class IssueRelationFixture extends CakeTestFixture {
  var $name = 'IssueRelation';
  var $import = array('table'=>'issue_relations');
  var $records = array(
  );
}