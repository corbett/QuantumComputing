<?php 
class CustomFieldsProjectFixture extends CakeTestFixture {
  var $name = 'CustomFieldsProject';
  var $import = array('table'=>'custom_fields_projects');
  var $records = array(
  );
}