<?php 
class WikiRedirectFixture extends CakeTestFixture {
  var $name = 'WikiRedirect';
  var $import = array('table'=>'wiki_redirects');
  var $records = array(
  );
}