<div id="footer">
&copy; 2011 - Cuonic.tk
</div>