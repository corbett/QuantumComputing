﻿namespace Quasar.Common.Enums
{
    public enum StartupType
    {
        LocalMachineRun,
        LocalMachineRunOnce,
        CurrentUserRun,
        CurrentUserRunOnce,
        LocalMachineWoW64Run,
        LocalMachineWoW64RunOnce,
        StartMenu
    }
}
