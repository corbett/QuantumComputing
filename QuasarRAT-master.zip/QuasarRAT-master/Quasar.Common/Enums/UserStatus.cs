﻿namespace Quasar.Common.Enums
{
    public enum UserStatus
    {
        Idle,
        Active
    }
}
