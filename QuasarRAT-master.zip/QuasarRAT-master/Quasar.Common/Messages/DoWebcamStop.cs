﻿using ProtoBuf;

namespace Quasar.Common.Messages
{
    [ProtoContract]
    public class DoWebcamStop : IMessage
    {
    }
}
