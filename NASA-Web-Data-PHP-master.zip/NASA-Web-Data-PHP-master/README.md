# NASA Web Data PHP Library

An unofficial library for pulling data from [nasa.gov](http://www.nasa.gov/).

## Example - Get launch calendar events

```php
$library = new \NASAWebData\NASACalendar();

// Set default timezone for start / end dates.
date_default_timezone_set('UTC');

// Get time range for events. Start today.
$startTime = time();
// End 30 days in the future.
$endTime = ($startTime + 2592000);

// Format date range.
$startDate = date('Ymd', $startTime) . '0000';
$endDate = date('Ymd', $endTime) . '2359';

// Limit events to launches.
$calendars = array(NASAWebData\NASACalendar::CALENDAR_LAUNCHES);

$dataSetIds = $library->getCalendarEventDataSetIds($startDate, $endDate, $calendars);

if (!empty($dataSetIds)) {
  $dataSetCount = count($dataSetIds);

  for ($i = 0; $i < $dataSetCount; $i++) {
    $eventData = $library->getDataSet($dataSetIds[$i]);

    // Use / store event data as needed.
    $event_title = $eventData->calendarEvent->title;
    $event_description = $eventData->calendarEvent->description;
    $event_timestamp = strtotime($eventData->calendarEvent->eventDate[0]->value . ' ' . $eventData->calendarEvent->eventDate[0]->timezone_db);
  }
}
```

## License

Released under the [MIT License](http://www.opensource.org/licenses/mit-license.php).
