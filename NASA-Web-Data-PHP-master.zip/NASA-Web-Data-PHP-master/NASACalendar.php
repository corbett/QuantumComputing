<?php

/**
 * Provides access to event calendar data from nasa.gov.
 */

namespace NASAWebData;

class NASACalendar extends NASAWebData {

  // Calendar ID constants.
  const CALENDAR_WORKSHOPS = 6088;
  const CALENDAR_LAUNCHES = 6089;
  const CALENDAR_ALL = 6090;

  /**
   * Gets the data set IDs of calendar events within a specified date range.
   *
   * @param string $startDate
   *   The start of the date range to limit calendar events to.
   *   Format: YYYYMMDDhhmm Example: 201208061200 (August 6th, 2012 at 12:00)
   * @param string $endDate
   *   The end of the date range to limit calendar events to.
   *   Format: YYYYMMDDhhmm Example: 201209061200 (September 6th, 2012 at 12:00)
   * @param array $calendars
   *   Array of calendar IDs to limit events to.
   *
   * @return array
   *   Array of calendar event data set IDs.
   */
  public function getCalendarEventDataSetIds($startDate, $endDate, array $calendars) {
    $path = '/query/calendar.json?timeRange=' . $startDate . '--' . $endDate . '&calendars=' . implode(',', $calendars);

    $data = $this->webRequest($path);

    $ids = array();

    if (!empty($data->calendarEvents)) {
      $eventCount = count($data->calendarEvents);

      for ($i = 0; $i < $eventCount; $i++) {
        $ids[$i] = $data->calendarEvents[$i]->nid;
      }
    }

    return $ids;
  }

}
