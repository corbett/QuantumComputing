<?php

/**
 * An unofficial library for pulling data from nasa.gov.
 *
 * Version 1.0
 */

namespace NASAWebData;

class NASAWebData {

  private $endpoint = 'http://www.nasa.gov/api/1';

  /**
   * Gets the data set for a given ID.
   *
   * See NASAWebData\NASACalendar for an example of data set IDs are found.
   *
   * @param int $id
   *   The ID of the data set.
   *
   * @return object
   *   The data set as a JSON-decoded object.
   */
  public function getDataSet($id) {
    $path = '/query/node/' . $id . '.json';

    return $this->webRequest($path);
  }

  /**
   * Makes a request to nasa.gov's API.
   *
   * @param string $path
   *   The API path to request.
   *
   * @return object
   *   An object created from the API's JSON response.
   */
  protected function webRequest($path) {
    $url = $this->endpoint . $path;

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

    $response = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($response);

    return $data;
  }

}
