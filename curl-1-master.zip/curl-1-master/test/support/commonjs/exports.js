define(function (require, exports) {
	exports.testMessage = 'it works';
});
