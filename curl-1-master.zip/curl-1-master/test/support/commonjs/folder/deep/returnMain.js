define(function (require, exports, module) {
	exports.id = function () { return require('../..').id; };
});
