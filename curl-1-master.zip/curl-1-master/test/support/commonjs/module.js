define(function (require, exports, module) {
	this.testMessage = module.id;
});
