define({

	labels: {
		beer: 'pint',
		abode: 'flat',
		transport: 'lorry'
	},

	values: {
		date: '01/01/2010',
		number: 5,
		boolean: true,
		string: 'string'
	}

});