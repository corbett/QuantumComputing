define(['eaf.util', 'eaf.core'], function (util, core) {
	return "it works";
});