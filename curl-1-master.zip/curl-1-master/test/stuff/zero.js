define('stuff/zero', function () { return 0; });
