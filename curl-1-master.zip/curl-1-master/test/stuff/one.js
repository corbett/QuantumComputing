/*
 * stuff/one
 */
//define(function () {
//	return 1;
//});
define(1);
