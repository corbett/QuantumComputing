define({
	root: {
		hello: 'hi coderz!'
	}
});
