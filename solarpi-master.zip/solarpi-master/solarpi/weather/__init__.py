"""The weather module."""

from . import views
