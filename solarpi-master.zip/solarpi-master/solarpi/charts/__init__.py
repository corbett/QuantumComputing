"""The data module."""

from . import views
