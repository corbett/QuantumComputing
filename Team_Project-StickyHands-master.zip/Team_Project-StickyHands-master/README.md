# Team_Project-StickyHands
Created repository for team project
## 0101000101111010101101101210101011010101010&#cdntvdbdbbdbdbdbdbdddbdbdbdgchfbcbdbdvdbdbdbdbdbdb
## veneno.iot.md
## dios.ros.md
