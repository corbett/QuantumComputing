window.example = 1 + 1;
