workbox.precaching.suppressWarnings();
workbox.precaching.precacheAndRoute([], {});
