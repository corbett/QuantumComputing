// Multiple entries.
workbox.precaching.precacheAndRoute([]);
workbox.precaching.precacheAndRoute([]);
