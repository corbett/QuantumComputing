workbox.precaching.precacheAndRoute([], {cleanUrls: true});
