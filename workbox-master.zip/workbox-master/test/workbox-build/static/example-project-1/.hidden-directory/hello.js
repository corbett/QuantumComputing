console.log('.hidden-directory/hello.js');
