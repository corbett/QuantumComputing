const gulp = require('gulp');

const getNpmCmd = require('./utils/get-npm-cmd');
const spawn = require('./utils/spawn-promise-wrapper');

gulp.task('publish-lerna', () => {
  return spawn(getNpmCmd(), [
    'run', 'local-lerna',
    '--',
    'publish',

    // The following flags can be used if publishing non-stable versions
    // '--cd-version=prerelease',
    // '--preid=beta',
    // '--npm-tag', 'beta',
  ]);
});
