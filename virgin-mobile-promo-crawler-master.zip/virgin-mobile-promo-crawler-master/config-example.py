# rename the file to example.py to make it working with the crawler

name = "John"
last_name = "Doe"
cell = "123456789"
email = "john.doe@emai.com"

chat_id = 45641231
bot_token = 'sdlfksjdf34j23kl4j23lk4h2j3h423h'
