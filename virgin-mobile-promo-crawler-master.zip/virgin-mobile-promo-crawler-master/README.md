# Virgin Mobile Promo Crawler
The script parsing [Virgin Mobile Canada website] (https://www.virginmobile.ca/en/members-lounge/index.html and submits your name/last name when it finds keywords "One entry per Member" or "One entry per Member per week.".
Once found it makes a list and submits your information via Selenium engine.

**Download Chrome browser**  
`sudo apt-get install chrome-browser`

**Download chrome driver**  
`https://packages.debian.org/stretch/armhf/chromium-driver/download`  
`sudo dpkg-deb -x chromium-driver_63.0.3239.84-1~deb9u1_armhf.deb /`  
`sudo mv /usr/bin/chromedriver /usr/local/bin/` 

**Install required pip packages:**\
`sudo pip3 install selenium`  
`sudo pip3 install beautifulsoup4`  
`sudo pip3 install python-telegram-bot`  

**Fill your information at config.py**

Check log example [here](virgin.log)

*Capable to send Telegram notifications. You need to configure Telegram bot for that*

![Telegram bot](https://image.ibb.co/hYwP98/photo.jpg)
