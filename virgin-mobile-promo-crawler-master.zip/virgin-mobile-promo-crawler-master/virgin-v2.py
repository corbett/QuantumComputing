# Install required APT packages:
# sudo apt-get update
# sudo apt-get install chrome-browser

# Download chrome driver
# https://packages.debian.org/stretch/armhf/chromium-driver/download
# sudo dpkg-deb -x chromium-driver_63.0.3239.84-1~deb9u1_armhf.deb /
# sudo mv /usr/bin/chromedriver /usr/local/bin/

# Install required pip packages:
# sudo pip3 install selenium
# sudo pip3 install beautifulsoup4
# sudo pip3 install python-telegram-bot

# ------------------------------------------------------------------------------

from datetime import datetime  # need it for shelve dictionary keys
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import TimeoutException
from urllib.request import urlopen
from bs4 import BeautifulSoup
import telegram
import logging
import config
import shelve

# Logging to file "virgin.log" in format "30/03/2018 16:51:34 | Parsing Virgin Promotions site"
logging.basicConfig(filename="virgin.log", format='%(asctime)s | %(message)s', datefmt='%d/%m/%Y %H:%M:%S', level=logging.INFO)


# ------------------------------------ CLASSES -----------------------------------

def TelegramSend(result, title):
    if result == 1:
        result = " OK | "
    elif result == 0:
        result = " ERROR | "
    elif result == 2:
        result = " NOTICE | "

    title = "*" + title + "*"

    bot = telegram.Bot(token=config.bot_token)
    message_text = result + title
    bot.send_message(chat_id=config.chat_id, text=message_text, parse_mode=telegram.ParseMode.MARKDOWN)


def SeleniumOpen(list):
    options = webdriver.ChromeOptions()
    options.add_argument('headless')
    options.add_argument('--no-sandbox')
    chrome_driver_binary = '/usr/local/bin/chromedriver'

    logging.info("\tLoading Chromium")
    browser = webdriver.Chrome(chrome_driver_binary, chrome_options=options)
    for url in list:
        logging.info("\t---------------")
        logging.info("\tLoading " + '\"' + url + '\"')
        browser.get(url)
        delay = 10  # secs
        try:
            my_elem = WebDriverWait(browser, delay).until(EC.presence_of_element_located((By.ID, 'submit')))
            logging.info("\tOK | Page is loaded " + '\"' + browser.title + '\"')
        except TimeoutException:
            logging.info("\tERROR | Loading takes too much time!")
            browser.quit()
            logging.info("\tClosing Chromium")
            raise

        logging.info("\tFilling the page")
        firstname = browser.find_element_by_name("params.firstname")
        lastname = browser.find_element_by_name("params.lastname")
        phone = browser.find_element_by_name("params.mdn")
        mail = browser.find_element_by_name("params.email")
        terms = browser.find_element_by_name("params.termsandconditions")

        firstname.send_keys(config.name)
        lastname.send_keys(config.last_name)
        phone.send_keys(config.cell)
        mail.send_keys(config.email)
        terms.click()

        try:
            browser.find_element_by_name("params.age19").click()
        except:
            logging.debug("\tNo age restriction option to click on.")

        logging.info("\tSubmitting")
        browser.find_element_by_id("submit").click()

        try:
            my_elem = WebDriverWait(browser, delay).until(
                EC.visibility_of_element_located((By.CSS_SELECTOR, ".successfulEntry")))
            logging.info("\tSUCCESS | Bingo! We submitted this promotion.")
            logging.info("\tSending Telegram notification")
            #TelegramSend(1, browser.title)
            # getting success text from the site
            TelegramNotification = my_elem.text + "\n" + url
            TelegramSend(1, TelegramNotification)
        except TimeoutException:
            logging.info("\tERROR | Couldn't submit entry for " + '\"' + browser.title + '\"')
            TelegramSend(0, browser.title)

    browser.quit()
    logging.info("\tClosing Chromium")


# ------------------------------------ CLASSES -----------------------------------
virgin_promotions = "https://www.virginmobile.ca/en/members-lounge/index.html"
UrllistWeekly = []
UrllistOnce = []

# open once submitted entries to check if we submitted this entry already
UrllistOnceSubmitted = shelve.open('UrllistOnceSubmitted', 'c')

# ------------------------------------- Virgin site parsing -----------------------
page = urlopen(virgin_promotions)
soup = BeautifulSoup(page, 'html.parser')
divTag = soup.find("div", {"class": "toutlistitem active"})

logging.info("Parsing Virgin Promotions site")
for EachPart in divTag.select('div[class*="tout"]'):
    title = (EachPart.get_text()).strip()
    url = (EachPart.find('a')['href']).strip()
    # Make proper URL with domain name
    url = "https://www.virginmobile.ca" + url

    if title:
        page = urlopen(url)
        soup = BeautifulSoup(page, 'html.parser')
        for ultag in soup.find_all('ul', {'class': 'standard-list'}):
            logging.info('Checking ' + '\"' + title + '\"')
            for litag in ultag.find_all('li'):
                if "Draws occur weekly" in litag.text:
                    logging.info('--- [WEEKLY PROMO]')
                    UrllistWeekly.append(url)
                # Checking if it's one time opportunity not weekly
                elif "One entry per Member" in litag.text and "One entry per Member per week" not in litag.text:
                    # assign datetime in format 2017-10-04 10:18:32.926
                    DateTime = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
                    if url not in UrllistOnceSubmitted:
                        # shelving one time URL for later
                        UrllistOnceSubmitted[url] = DateTime
                        # adding one time URL to submit now
                        UrllistOnce.append(url)
                        logging.info('--- [ONE TIME PROMO]')
                        logging.info('--- Adding URL to Shelve and single submission list. Key = ' + DateTime)
                    else:
                        logging.info('--- Already submitted on ' + UrllistOnceSubmitted[url])

# closing shelve object
UrllistOnceSubmitted.close()
# ------------------------------------- Selenium processing -----------------------

logging.info('------------------ PARSING COMPLETED --------------------')
logging.info('Checking if the list of weekly URLs is empty')
if UrllistWeekly:
    logging.info('Weekly list is not empty. Opening Selenium class')
    logging.info('----------------- WEEKLY SUBMISSIONS STARTING ------------------------')
    SeleniumOpen(UrllistWeekly)
    logging.info('----------------- WEEKLY SUBMISSION COMPLETED ------------------------')
else:
    logging.info('Weekly list is empty')

logging.info('Checking if the list of single submission URLs is empty')
if UrllistOnce:
    logging.info('Single submission URL list is not empty. Opening Selenium class')
    logging.info('----------------- ONE TIME SUBMISSIONS STARTING ------------------------')
    SeleniumOpen(UrllistOnce)
    logging.info('----------------- ONE TIME SUBMISSIONS COMPLETED ------------------------')
else:
    logging.info('Single submission list is empty')

logging.info('=================================================================================================')

