# romeo-juliet

An attempt to model the famous Romeo and Juliet as a reactive program with Akka. See the blog post at http://blog.shadaj.me/2015/07/14/romeo-juliet-and-reactive-programming.html.
