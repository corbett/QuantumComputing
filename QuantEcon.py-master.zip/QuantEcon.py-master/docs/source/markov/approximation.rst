approximation
=============

.. automodule:: quantecon.markov.approximation
    :members:
    :undoc-members:
    :show-inheritance:
