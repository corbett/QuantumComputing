random
======

.. automodule:: quantecon.markov.random
    :members:
    :undoc-members:
    :show-inheritance:
