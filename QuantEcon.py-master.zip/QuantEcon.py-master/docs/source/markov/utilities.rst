utilities
=========

.. automodule:: quantecon.markov.utilities
    :members:
    :undoc-members:
    :show-inheritance:
