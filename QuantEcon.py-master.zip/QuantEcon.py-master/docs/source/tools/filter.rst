filter
======

.. automodule:: quantecon.filter
    :members:
    :undoc-members:
    :show-inheritance:
