matrix_eqn
==========

.. automodule:: quantecon.matrix_eqn
    :members:
    :undoc-members:
    :show-inheritance:
