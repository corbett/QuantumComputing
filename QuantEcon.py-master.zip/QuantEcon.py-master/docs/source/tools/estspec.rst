estspec
=======

.. automodule:: quantecon.estspec
    :members:
    :undoc-members:
    :show-inheritance:
