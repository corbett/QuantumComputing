Optimize
========

.. toctree::
   :maxdepth: 2

   optimize/root_finding
   optimize/scalar_maximization
