numba
=====

.. automodule:: quantecon.util.numba
    :members:
    :undoc-members:
    :show-inheritance:
