timing
======

.. automodule:: quantecon.util.timing
    :members:
    :undoc-members:
    :show-inheritance:
