random
======

.. automodule:: quantecon.game_theory.random
    :members:
    :undoc-members:
    :show-inheritance:
