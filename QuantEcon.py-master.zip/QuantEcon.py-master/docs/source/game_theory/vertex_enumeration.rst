vertex_enumeration
==================

.. automodule:: quantecon.game_theory.vertex_enumeration
    :members:
    :undoc-members:
    :show-inheritance:
