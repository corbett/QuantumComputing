normal_form_game
================

.. automodule:: quantecon.game_theory.normal_form_game
    :members:
    :undoc-members:
    :show-inheritance:
