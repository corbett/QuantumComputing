
## Quantitative Economics 

This repository collects code for [Quantitative Economics](http://quant-econ.net),  an on-line course on quantitative economic modeling authored by [Thomas J. Sargent](https://files.nyu.edu/ts43/public/) and [John Stachurski](http://johnstachurski.net).

Visit the [lecture series main page](http://quant-econ.net) to find detailed information on working with this code repository.


