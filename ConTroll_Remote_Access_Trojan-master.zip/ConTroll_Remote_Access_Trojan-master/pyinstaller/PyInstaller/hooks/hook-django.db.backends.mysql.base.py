# Compiler module (see class DatabaseOperations)
hiddenimports = ["django.db.backends.mysql.compiler"]
