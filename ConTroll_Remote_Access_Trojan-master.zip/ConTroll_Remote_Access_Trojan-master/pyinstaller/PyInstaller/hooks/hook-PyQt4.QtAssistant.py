hiddenimports = ['sip', 'PyQt4.QtCore', 'PyQt4._qt']

