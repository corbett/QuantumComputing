name = 'relimp.B.D'

class X:
    name = 'relimp.B.D.X'
