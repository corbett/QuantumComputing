import wx
app = wx.App(0)
frame = wx.Frame(None, title="Hello World from wxPython", size=(320, 240))
