#!/usr/bin/env python
# -*- coding: utf-8 -*-

from numpy.core.numeric import dot


def main():
    print "dot(3, 4):", dot(3, 4)


if __name__ == "__main__":
    main()
