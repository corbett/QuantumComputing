""" pkg2.a defines overridden and a_func """

def a_func():
    return "a_func from pkg2.a"
print "pkg2.a imported"
