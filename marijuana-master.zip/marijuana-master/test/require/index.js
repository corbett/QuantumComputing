require('babel-register')()
