# TOC
   - [lib](#lib)
<a name=""></a>
 
<a name="lib"></a>
# lib
should have default function export.

```js
should.exist(lib.default);
lib.default.should.be.a('function');
```

