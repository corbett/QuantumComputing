# marijuana

**Medical Marijuana API**


[![Build Status](https://travis-ci.org/noderaider/marijuana.svg?branch=master)](https://travis-ci.org/noderaider/marijuana)
[![codecov](https://codecov.io/gh/noderaider/marijuana/branch/master/graph/badge.svg)](https://codecov.io/gh/noderaider/marijuana)

[![NPM](https://nodei.co/npm/marijuana.png?stars=true&downloads=true)](https://nodei.co/npm/marijuana/)


## Install

`npm i -S marijuana`


**This project is in active development. Please come back in a couple of weeks.**
