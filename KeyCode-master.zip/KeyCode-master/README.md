[![build](https://img.shields.io/travis/SIGSEV/KeyCode.svg?style=flat-square)](https://travis-ci.org/SIGSEV/KeyCode)

<h1 align="center">KeyCode</h1>
<p align="center">:keyboard: Improve your coding speed, like a god.</p>

### Development

Just figure that shit by looking at the `package.json`, lazy biatch.
