Jack Grigg (1):
      Disable building Proton in Gitian

Sean Bowe (2):
      Revert "Remove an unneeded version workaround as per @str4d's review comment."
      Revert "Delete old protocol version constants and simplify code that used them."

Simon Liu (2):
      make-release.py: Versioning changes for 1.0.10-1.
      make-release.py: Updated manpages for 1.0.10-1.

