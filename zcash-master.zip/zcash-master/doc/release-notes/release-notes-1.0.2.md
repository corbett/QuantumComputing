ITH4Coinomia (2):
      Update security-warnings.md
      Update init.cpp

S. Matthew English (1):
      enforcing consistency 'tor' to 'Tor'

Sean Bowe (1):
      Write R1CS output to file in GenerateParams.

Simon (4):
      Fixes #1762 segfault when miner is interrupted.
      Fixes #1779 so that sending to multiple zaddrs no longer fails.
      Add GenIdentity, an identity function for MappedShuffle.
      Add transaction size and zaddr output limit checks to z_sendmany.

