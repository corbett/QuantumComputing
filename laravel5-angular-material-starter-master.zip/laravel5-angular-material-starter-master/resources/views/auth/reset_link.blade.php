Your reset password link:

<a href="{{config('app.url')}}/#/reset-password/{{$email}}/{{$token}}">
{{config('app.url')}}/#/reset-password/{{$email}}/{{$token}}
</a>
