﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Cronos.Tests")]
