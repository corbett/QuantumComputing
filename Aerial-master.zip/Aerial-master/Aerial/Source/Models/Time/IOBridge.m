//
//  IOBridge.m
//  Aerial
//
//  Created by Guillaume Louel on 26/10/2018.
//  Copyright © 2018 John Coates. All rights reserved.
//
// We need this to be able to use IOPowerSources for battery status detection in Swift

#import <Foundation/Foundation.h>
